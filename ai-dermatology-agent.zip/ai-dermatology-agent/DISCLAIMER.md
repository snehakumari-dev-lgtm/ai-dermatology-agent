# Medical & Scope Disclaimer

This software is an **educational research prototype** for preliminary screening support.

- It is **not a medical device**, is **not approved or validated for clinical use**, and provides **no diagnosis**.
- It **does not replace** a dermatologist or any qualified healthcare professional.
- The image model can only output the **7 HAM10000 classes** (akiec, bcc, bkl, df, mel, nv, vasc). It cannot recognise rashes,
  eczema, psoriasis, fungal/bacterial/viral infections, acne, hair or nail disease, or any condition outside those classes.
- HAM10000 is dominated by dermoscopic images of lighter-skinned patients. Performance on darker skin tones, smartphone photos
  and other body sites is likely worse and has **not** been measured here.
- The knowledge base is a set of student-written educational summaries, **not clinician-reviewed guidelines**.
- Urgency categories come from simple, conservative, developer-defined rules, **not a validated clinical score**.
- If you are worried about your skin, or have emergency symptoms (fever with a spreading rash, facial/throat swelling,
  breathing difficulty, widespread blistering), **seek medical care immediately**.
