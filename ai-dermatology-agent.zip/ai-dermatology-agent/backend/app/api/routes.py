"""HTTP routes: /api/v1/health, /api/v1/analyze, /api/v1/chat."""
from __future__ import annotations

import json

from fastapi import APIRouter, File, Form, Request, UploadFile
from fastapi.concurrency import run_in_threadpool
from pydantic import ValidationError

from ..errors import InvalidMetadata, PayloadTooLarge
from ..schemas import (
    AnalyzeResponse, ChatRequest, ChatResponse, ClinicalMetadata, ErrorResponse, HealthResponse,
)

router = APIRouter(prefix="/api/v1")


@router.get("/health", response_model=HealthResponse, tags=["system"])
async def health(request: Request) -> HealthResponse:
    st = request.app.state
    vision, kb, llm = st.pipeline.vision, st.pipeline.kb, st.pipeline.llm
    ok = vision.can_predict and kb.available
    return HealthResponse(
        status="ok" if ok else "degraded",
        version=st.settings.app_version,
        model_name=vision.info().name,
        model_status=vision.status,
        rag_available=kb.available,
        rag_backend=kb.backend,
        knowledge_chunks=len(kb.chunks),
        llm_configured=llm.configured,
        notice=vision.info().notice,
    )


@router.post(
    "/analyze", response_model=AnalyzeResponse, tags=["analysis"],
    responses={413: {"model": ErrorResponse}, 415: {"model": ErrorResponse}, 422: {"model": ErrorResponse}},
)
async def analyze(
    request: Request,
    image: UploadFile = File(..., description="JPEG/PNG/WebP skin image"),
    metadata: str = Form("{}", description="JSON-encoded ClinicalMetadata"),
) -> AnalyzeResponse:
    st = request.app.state
    limit = st.settings.max_upload_bytes
    data = await image.read(limit + 1)
    if len(data) > limit:
        raise PayloadTooLarge(f"Image exceeds the {st.settings.max_upload_mb} MB limit.")
    try:
        meta = ClinicalMetadata.model_validate(json.loads(metadata or "{}"))
    except (json.JSONDecodeError, ValidationError) as exc:
        detail = exc.errors()[0]["msg"] if isinstance(exc, ValidationError) else "not valid JSON"
        raise InvalidMetadata(f"Invalid clinical metadata: {detail}") from exc
    return await run_in_threadpool(st.pipeline.analyze, data, meta)


@router.post("/chat", response_model=ChatResponse, tags=["analysis"])
async def chat(request: Request, body: ChatRequest) -> ChatResponse:
    return await run_in_threadpool(request.app.state.pipeline.chat, body)
