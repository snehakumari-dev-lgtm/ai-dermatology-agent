"""Application configuration, loaded from environment variables / backend/.env."""
from __future__ import annotations

from functools import lru_cache
from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict

BACKEND_DIR = Path(__file__).resolve().parents[1]


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=BACKEND_DIR / ".env", env_file_encoding="utf-8", extra="ignore"
    )

    app_name: str = "AI Dermatology Decision-Support Agent"
    app_version: str = "0.1.0"
    log_level: str = "INFO"
    log_json: bool = False
    cors_origins: str = "http://localhost:5173,http://127.0.0.1:5173"

    # --- Vision model ---
    model_checkpoint: Path = BACKEND_DIR / "models" / "skin_lesion_effnet_b0.pt"
    # If True and no checkpoint exists, load RANDOM weights in an explicitly
    # labelled demo mode (pipeline/UI testing only; predictions are meaningless).
    allow_untrained_demo: bool = False
    device: str = "cpu"
    enable_gradcam: bool = True
    top_k: int = 3
    low_confidence_threshold: float = 0.5

    # --- Upload limits ---
    max_upload_mb: int = 8
    min_image_side: int = 64

    # --- RAG ---
    knowledge_dir: Path = BACKEND_DIR / "app" / "knowledge"
    rag_backend: str = "tfidf"  # "tfidf" (no downloads) or "faiss" (sentence-transformers)
    rag_embedding_model: str = "sentence-transformers/all-MiniLM-L6-v2"
    rag_top_k: int = 4

    # --- LLM (any OpenAI-compatible /chat/completions endpoint) ---
    llm_base_url: str = "https://api.openai.com/v1"
    llm_api_key: str = ""
    llm_model: str = "gpt-4o-mini"
    llm_timeout_s: float = 30.0
    llm_max_tokens: int = 450

    @property
    def cors_origin_list(self) -> list[str]:
        return [o.strip() for o in self.cors_origins.split(",") if o.strip()]

    @property
    def max_upload_bytes(self) -> int:
        return self.max_upload_mb * 1024 * 1024


@lru_cache
def get_settings() -> Settings:
    return Settings()
