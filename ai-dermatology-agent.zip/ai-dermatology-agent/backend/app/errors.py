"""Typed API errors rendered as {"error": {"code", "message"}}."""
from __future__ import annotations


class ApiError(Exception):
    status_code = 400
    code = "bad_request"

    def __init__(self, message: str):
        super().__init__(message)
        self.message = message


class UnsupportedMediaType(ApiError):
    status_code = 415
    code = "unsupported_media_type"


class PayloadTooLarge(ApiError):
    status_code = 413
    code = "payload_too_large"


class InvalidImage(ApiError):
    status_code = 422
    code = "invalid_image"


class InvalidMetadata(ApiError):
    status_code = 422
    code = "invalid_metadata"
