# Family history and skin cancer

## Overview
Having a close relative with melanoma or other skin cancer can raise your own risk, as can sharing skin type and sun exposure patterns. Family history cannot by itself show that you have or will develop a condition.

## When to seek care
- Tell your doctor about any parent, sibling or child with melanoma
- People with a family history of melanoma often benefit from regular full-body skin checks and careful sun protection
