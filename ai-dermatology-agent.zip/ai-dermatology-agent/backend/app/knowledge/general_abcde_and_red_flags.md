# ABCDE rule and skin-cancer warning signs

## Overview
The ABCDE rule is a simple self-check for moles and spots. It raises suspicion; it cannot rule skin cancer in or out.

## Typical features
- A: Asymmetry, the two halves do not match
- B: Border is irregular, ragged or blurred
- C: Colour varies or has several shades
- D: Diameter is larger than about 6 mm
- E: Evolving, any change in size, shape, colour, or new bleeding, itching or crusting
- Also look for the "ugly duckling", a mole that looks different from all your others
