# General skin-care precautions

## Precautions
- Do not scratch, pick, burn or cut any skin lesion yourself
- Keep the area clean and dry, and avoid products that sting or irritate it
- Protect your skin from sun with shade, clothing and broad-spectrum SPF 30 or higher sunscreen
- Avoid tanning beds and sunburn
- Take dated photos with a ruler to track changes, and show them to a clinician
- Do not start prescription-strength creams or steroids without medical advice
