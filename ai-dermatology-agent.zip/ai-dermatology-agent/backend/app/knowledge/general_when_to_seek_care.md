# When to seek medical care

## When to seek care
- A lesion that is new, growing, changing in colour or shape, bleeding, or not healing within 4 weeks should be examined
- Skin problems that are painful, spreading, oozing pus, or accompanied by increasing warmth and redness should be assessed soon
- A rash lasting more than a few weeks, or returning repeatedly, deserves a clinician's review
- If you are worried, get it checked; a normal-looking result from this tool never rules out a problem

## Emergency warning signs
- Fever with a rapidly spreading red, painful or blistering rash
- Swelling of the face, lips, tongue or throat, or difficulty breathing
- Widespread blistering or peeling skin, or sores in the mouth or eyes
- Feeling very unwell, confused or faint along with a skin change
