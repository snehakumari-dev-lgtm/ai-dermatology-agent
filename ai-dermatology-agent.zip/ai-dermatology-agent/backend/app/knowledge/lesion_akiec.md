# Actinic keratosis and intraepithelial carcinoma

## Overview
Actinic keratoses are rough, scaly patches caused by long-term sun damage. Some can progress to squamous cell carcinoma, and Bowen's disease (intraepithelial carcinoma) is an early, surface-level form of squamous cell skin cancer.

## Typical features
- Dry, rough or scaly patch, sometimes easier to feel than to see
- Pink, red, brown or skin-coloured; can be tender or itchy
- Typically on the face, scalp, ears, backs of hands and forearms

## Precautions
- Do not scrape or pick the scaly area
- Use daily broad-spectrum sunscreen, protective clothing and shade
- Moisturise dry skin but avoid applying unprescribed medicated creams to the patch

## When to seek care
- Have patches that persist, thicken, bleed or become painful reviewed by a clinician
- People with many sun-damaged patches benefit from regular skin checks
