# Basal cell carcinoma

## Overview
Basal cell carcinoma (BCC) is the most common skin cancer. It grows slowly, rarely spreads to other organs, but can damage local tissue if left untreated.

## Typical features
- Pearly or waxy bump, often with visible small blood vessels
- A sore that bleeds, crusts or does not heal over several weeks
- Flat, scaly pink or flesh-coloured patch; occasionally a scar-like area
- Most often on sun-exposed skin such as the face, ears, neck and scalp

## Precautions
- Do not pick at or repeatedly irritate a non-healing sore
- Use broad-spectrum sunscreen, a hat and shade on exposed areas
- Keep the area clean and covered if it bleeds, and avoid home remedies

## When to seek care
- See a doctor or dermatologist if a sore has not healed within 4 weeks or keeps bleeding
- Seek prompt review for lesions near the eyes, nose, lips or ears, as treatment there is more delicate
