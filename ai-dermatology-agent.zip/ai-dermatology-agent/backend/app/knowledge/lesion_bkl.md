# Benign keratosis-like lesions

## Overview
This group includes seborrheic keratoses, solar lentigines and lichen-planus-like keratoses. They are common, non-cancerous growths that tend to appear with age. They can look similar to melanoma, so a clinician should confirm anything unusual.

## Typical features
- Waxy, "stuck-on" brown or black raised spots, or flat tan age spots
- Well-defined edges and a rough or slightly greasy surface
- Often multiple, on the trunk, face and arms

## Precautions
- Avoid scratching or picking; irritated lesions can bleed or become infected
- Note any sudden change in colour, size or bleeding
- Use sun protection to limit new sun spots

## When to seek care
- See a clinician if a lesion changes quickly, bleeds, itches persistently or looks different from the others
- Cosmetic removal, if wanted, should be done by a clinician
