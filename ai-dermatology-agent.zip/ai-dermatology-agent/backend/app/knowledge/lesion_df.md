# Dermatofibroma

## Overview
A dermatofibroma is a common, harmless, firm skin nodule, often on the legs, thought to be a reaction to minor injury such as an insect bite.

## Typical features
- Small, firm, brownish or pink bump that dimples inward when pinched
- Usually stable for years; may be mildly itchy or tender

## Precautions
- Avoid shaving over the bump, which can cause bleeding
- No treatment is usually needed; do not try to cut or burn it at home

## When to seek care
- See a clinician if it grows quickly, bleeds, changes colour or you are unsure what it is
