# Melanoma

## Overview
Melanoma is a cancer of pigment-producing cells (melanocytes). It is less common than other skin cancers but more likely to spread if not found early. Early detection and removal greatly improve outcomes.

## Typical features
- Asymmetry, irregular or notched border, more than one colour (brown, black, blue, red, white)
- Diameter often larger than 6 mm, though smaller melanomas exist
- Evolving: change in size, shape, colour, or new itching, bleeding or crusting
- Can appear as a new dark spot or a change in an existing mole; some are not dark at all

## Precautions
- Do not scratch, pick or try to remove the lesion yourself
- Photograph the lesion with a ruler beside it to track change, but do not delay medical review
- Protect the area from sun and avoid tanning beds
- Check the rest of your skin, including the scalp, soles and between toes

## When to seek care
- Arrange a dermatologist or doctor visit promptly if a mole is new, changing, bleeding or looks different from your other moles
- Ask for a full-body skin check if you have many moles or a family history of melanoma
