# Melanocytic nevus

## Overview
Melanocytic nevi are ordinary moles formed by clusters of pigment cells. Most are harmless, but having many moles slightly raises melanoma risk, so monitoring matters.

## Typical features
- Evenly coloured brown, tan or pink spot with a smooth, regular border
- Round or oval, usually smaller than 6 mm
- Flat or slightly raised and stable over time

## Precautions
- Learn your moles and check your skin monthly, using the ABCDE rule
- Use sun protection; avoid sunburn and tanning beds
- Photograph moles at intervals to notice change

## When to seek care
- See a clinician if a mole changes in size, shape or colour, bleeds, itches persistently, or is a new mole in adulthood that looks different from your others
