# Vascular lesions

## Overview
Vascular lesions include cherry angiomas, angiokeratomas and pyogenic granulomas, formed from small blood vessels. Most are harmless, but some bleed easily, and a bruise-like or dark spot can look like other conditions.

## Typical features
- Bright red, purple or blue-red spots or bumps
- Cherry angiomas are small, smooth and often multiple
- Pyogenic granulomas grow quickly and bleed easily

## Precautions
- Apply gentle firm pressure with clean gauze if it bleeds
- Avoid picking or scratching and protect it from friction
- Do not self-treat with sharp tools

## When to seek care
- See a clinician if a red or purple lesion grows fast, bleeds repeatedly, or changes appearance
- Seek care if a dark spot with a vascular look does not fade or you are unsure what it is
