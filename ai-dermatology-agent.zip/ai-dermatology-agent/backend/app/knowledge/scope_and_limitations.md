# Scope and limitations of this tool

## Overview
This student research tool uses a small image classifier trained on a limited public dataset (HAM10000), which mostly contains dermoscopic images of pigmented lesions from specific populations. It does not cover rashes, eczema, psoriasis, infections, acne, hair or nail conditions, and it may perform worse on darker skin tones and non-dermoscopic phone photos. Its output is a screening signal, never a diagnosis.
