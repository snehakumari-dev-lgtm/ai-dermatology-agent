# Common skin symptoms

## Itching
Itching has many causes, including dry skin, eczema, allergic reactions, insect bites and infections. A new itch in an existing mole or lesion is a reason for review. Moisturising and avoiding scratching can help mild itch.

## Pain
Pain or tenderness can accompany infection, inflammation or injury. A painful, warm, spreading red area may be a bacterial skin infection needing prompt care.

## Redness
Redness can reflect irritation, allergy, sunburn or infection. Redness that spreads quickly, is hot, or comes with fever should be assessed urgently.
