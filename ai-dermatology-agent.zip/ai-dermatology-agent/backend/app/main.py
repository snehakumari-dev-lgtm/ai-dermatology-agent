"""FastAPI application factory."""
from __future__ import annotations

import logging
import time
import uuid
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from .api.routes import router
from .config import get_settings
from .errors import ApiError
from .logging_config import setup_logging
from .services.llm import LLMClient
from .services.pipeline import AnalysisPipeline
from .services.rag import KnowledgeBase
from .services.vision import VisionModel

log = logging.getLogger("app")


def create_app() -> FastAPI:
    settings = get_settings()
    setup_logging(settings.log_level, settings.log_json)

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        vision = VisionModel(settings)
        vision.load()
        kb = KnowledgeBase(settings.knowledge_dir, settings.rag_backend, settings.rag_embedding_model, settings.rag_top_k)
        kb.load()
        app.state.settings = settings
        app.state.pipeline = AnalysisPipeline(settings, vision, kb, LLMClient(settings))
        log.info("Ready: model=%s rag=%s llm=%s", vision.status, kb.backend, app.state.pipeline.llm.configured)
        yield

    app = FastAPI(
        title=settings.app_name, version=settings.app_version, lifespan=lifespan,
        description="Educational dermatology decision-support API. Not a medical device; not a diagnosis.",
    )
    app.add_middleware(
        CORSMiddleware, allow_origins=settings.cors_origin_list, allow_methods=["GET", "POST"], allow_headers=["*"],
    )

    @app.middleware("http")
    async def access_log(request: Request, call_next):
        rid, start = uuid.uuid4().hex[:12], time.perf_counter()
        try:
            response = await call_next(request)
        except Exception:
            log.exception("Unhandled error", extra={"request_id": rid, "path": request.url.path})
            return JSONResponse(
                status_code=500,
                content={"error": {"code": "internal_error", "message": "Something went wrong on the server."}},
            )
        response.headers["X-Request-ID"] = rid
        log.info(
            "%s %s", request.method, request.url.path,
            extra={"request_id": rid, "path": request.url.path, "status": response.status_code,
                   "duration_ms": round((time.perf_counter() - start) * 1000)},
        )
        return response

    @app.exception_handler(ApiError)
    async def api_error_handler(_: Request, exc: ApiError):
        return JSONResponse(status_code=exc.status_code, content={"error": {"code": exc.code, "message": exc.message}})

    @app.exception_handler(RequestValidationError)
    async def validation_handler(_: Request, exc: RequestValidationError):
        first = exc.errors()[0]
        loc = ".".join(str(p) for p in first["loc"] if p != "body")
        return JSONResponse(status_code=422, content={"error": {"code": "validation_error", "message": f"{loc}: {first['msg']}"}})

    app.include_router(router)
    return app


app = create_app()
