"""Pydantic v2 request/response schemas."""
from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field, field_validator

Severity = Literal["none", "mild", "moderate", "severe"]
LesionChange = Literal[
    "size", "color", "shape", "border", "bleeding", "ulceration", "crusting", "itching_new"
]
UrgencyLevel = Literal["routine", "soon", "urgent", "emergency"]


class FamilyHistory(BaseModel):
    skin_cancer: bool = False
    melanoma: bool = False
    other_conditions: str | None = Field(default=None, max_length=200)
    relatives: list[str] = Field(default_factory=list, max_length=6)


class ClinicalMetadata(BaseModel):
    """Patient-reported context. All fields optional; nothing here is a diagnosis."""

    age: int | None = Field(default=None, ge=0, le=120)
    sex: Literal["female", "male", "other", "unspecified"] = "unspecified"
    body_site: str | None = Field(default=None, max_length=60)
    itching: Severity = "none"
    pain: Severity = "none"
    redness: Severity = "none"
    duration_days: int | None = Field(default=None, ge=0, le=36500)
    lesion_changes: list[LesionChange] = Field(default_factory=list, max_length=8)
    has_fever: bool = False
    rapidly_spreading: bool = False
    previous_conditions: list[str] = Field(default_factory=list, max_length=10)
    family_history: FamilyHistory | None = None
    notes: str | None = Field(default=None, max_length=500)

    @field_validator("previous_conditions")
    @classmethod
    def _short_items(cls, v: list[str]) -> list[str]:
        return [s.strip()[:80] for s in v if s.strip()]


class Prediction(BaseModel):
    label: str
    name: str
    category: Literal["malignant", "premalignant", "benign"]
    confidence: float = Field(ge=0, le=1)


class ModelInfo(BaseModel):
    status: Literal["ready", "demo_untrained", "no_checkpoint", "torch_missing", "load_error"]
    name: str
    trained_on: str | None = None
    classes: list[str]
    held_out_metrics: dict[str, float] | None = None
    clinically_validated: Literal[False] = False
    notice: str


class GradCamResult(BaseModel):
    available: bool
    image_base64: str | None = None
    target_label: str | None = None
    note: str


class Citation(BaseModel):
    source: str
    title: str
    section: str
    snippet: str
    score: float


class RiskAssessment(BaseModel):
    level: UrgencyLevel
    label: str
    rationale: list[str]


class AnalyzeResponse(BaseModel):
    request_id: str
    model: ModelInfo
    predictions: list[Prediction]
    inconclusive: bool
    gradcam: GradCamResult
    risk: RiskAssessment
    explanation: str
    explanation_source: Literal["llm", "template"]
    precautions: list[str]
    referral_guidance: list[str]
    citations: list[Citation]
    warnings: list[str]
    scope_notice: str
    disclaimer: str


class ChatTurn(BaseModel):
    role: Literal["user", "assistant"]
    content: str = Field(max_length=1500)


class ChatRequest(BaseModel):
    question: str = Field(min_length=2, max_length=1000)
    context_labels: list[str] = Field(default_factory=list, max_length=3)
    risk_level: UrgencyLevel | None = None
    history: list[ChatTurn] = Field(default_factory=list, max_length=6)


class ChatResponse(BaseModel):
    answer: str
    source: Literal["llm", "knowledge_base"]
    citations: list[Citation]
    disclaimer: str


class HealthResponse(BaseModel):
    status: Literal["ok", "degraded"]
    version: str
    model_name: str
    model_status: str
    rag_available: bool
    rag_backend: str
    knowledge_chunks: int
    llm_configured: bool
    notice: str


class ErrorBody(BaseModel):
    code: str
    message: str


class ErrorResponse(BaseModel):
    error: ErrorBody
