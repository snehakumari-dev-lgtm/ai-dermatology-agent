"""Class vocabulary of the vision model.

The classifier can ONLY output these seven HAM10000 diagnostic categories.
It cannot recognise rashes, eczema, psoriasis, fungal/bacterial infections,
acne, hair or nail disease, etc. The order here MUST match ml/classes.py.
"""
from __future__ import annotations

from typing import Literal, TypedDict

Category = Literal["malignant", "premalignant", "benign"]


class ClassInfo(TypedDict):
    name: str
    category: Category


CLASSES: list[str] = ["akiec", "bcc", "bkl", "df", "mel", "nv", "vasc"]

CLASS_INFO: dict[str, ClassInfo] = {
    "akiec": {"name": "Actinic keratosis / intraepithelial carcinoma (Bowen's disease)", "category": "premalignant"},
    "bcc": {"name": "Basal cell carcinoma", "category": "malignant"},
    "bkl": {"name": "Benign keratosis-like lesion (seborrheic keratosis, solar lentigo, lichen-planus-like keratosis)", "category": "benign"},
    "df": {"name": "Dermatofibroma", "category": "benign"},
    "mel": {"name": "Melanoma", "category": "malignant"},
    "nv": {"name": "Melanocytic nevus (common mole)", "category": "benign"},
    "vasc": {"name": "Vascular lesion (angioma, angiokeratoma, pyogenic granuloma, haemorrhage)", "category": "benign"},
}

CONCERNING = {"mel", "bcc", "akiec"}
