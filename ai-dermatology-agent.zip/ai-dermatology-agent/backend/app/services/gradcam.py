"""Grad-CAM (Selvaraju et al., 2017) for a torchvision CNN, no extra dependencies."""
from __future__ import annotations

import base64
import io

import numpy as np
import torch
from PIL import Image


class GradCAM:
    def __init__(self, model: torch.nn.Module, target_layer: torch.nn.Module):
        self.model = model
        self._acts: torch.Tensor | None = None
        self._grads: torch.Tensor | None = None
        self._handle = target_layer.register_forward_hook(self._on_forward)

    def _on_forward(self, _module, _inp, output: torch.Tensor) -> None:
        self._acts = output
        output.register_hook(lambda g: setattr(self, "_grads", g))

    def close(self) -> None:
        self._handle.remove()

    def __call__(self, x: torch.Tensor, class_idx: int) -> np.ndarray:
        """Return a [0,1] heatmap at the target layer's spatial resolution."""
        self.model.eval()
        self.model.zero_grad(set_to_none=True)
        with torch.enable_grad():
            x = x.clone().requires_grad_(True)
            logits = self.model(x)
            logits[0, class_idx].backward()
        assert self._acts is not None and self._grads is not None
        weights = self._grads.mean(dim=(2, 3), keepdim=True)
        cam = torch.relu((weights * self._acts).sum(dim=1))[0].detach().cpu().numpy()
        cam -= cam.min()
        peak = cam.max()
        return cam / peak if peak > 0 else cam


def _jet(v: np.ndarray) -> np.ndarray:
    """Minimal 'jet' colormap; v in [0,1] -> uint8 RGB."""
    r = np.clip(1.5 - np.abs(4 * v - 3), 0, 1)
    g = np.clip(1.5 - np.abs(4 * v - 2), 0, 1)
    b = np.clip(1.5 - np.abs(4 * v - 1), 0, 1)
    return (np.stack([r, g, b], axis=-1) * 255).astype(np.uint8)


def overlay_heatmap(img: Image.Image, cam: np.ndarray, alpha: float = 0.45, max_side: int = 512) -> str:
    """Blend the heatmap over the (downscaled) original and return a base64 PNG."""
    scale = min(1.0, max_side / max(img.size))
    base = img.resize((max(1, int(img.width * scale)), max(1, int(img.height * scale))))
    cam_img = Image.fromarray((cam * 255).astype(np.uint8)).resize(base.size, Image.BICUBIC)
    heat = _jet(np.asarray(cam_img, dtype=np.float32) / 255.0)
    blended = (1 - alpha) * np.asarray(base, dtype=np.float32) + alpha * heat
    out = Image.fromarray(blended.astype(np.uint8))
    buf = io.BytesIO()
    out.save(buf, format="PNG")
    return base64.b64encode(buf.getvalue()).decode("ascii")
