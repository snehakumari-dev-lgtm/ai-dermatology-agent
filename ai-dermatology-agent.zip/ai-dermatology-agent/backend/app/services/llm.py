"""Minimal OpenAI-compatible chat client. Returns None on ANY failure so callers fall back."""
from __future__ import annotations

import logging

import httpx

from ..config import Settings

log = logging.getLogger(__name__)

SYSTEM_PROMPT = (
    "You are an educational dermatology information assistant inside a student research project. "
    "Rules: (1) Use ONLY the provided context and findings; if they do not answer the question, say so. "
    "(2) Never give a diagnosis, never name medicines or doses. (3) The image model is a narrow "
    "7-class lesion classifier and its output is a screening signal, not a diagnosis. "
    "(4) Always encourage consulting a clinician for concerns. (5) Be concise and plain-language."
)


class LLMClient:
    def __init__(self, settings: Settings):
        self.s = settings

    @property
    def configured(self) -> bool:
        return bool(self.s.llm_api_key.strip())

    def complete(self, user_prompt: str, history: list[dict[str, str]] | None = None) -> str | None:
        if not self.configured:
            return None
        messages = [{"role": "system", "content": SYSTEM_PROMPT}, *(history or []),
                    {"role": "user", "content": user_prompt}]
        try:
            r = httpx.post(
                f"{self.s.llm_base_url.rstrip('/')}/chat/completions",
                headers={"Authorization": f"Bearer {self.s.llm_api_key}"},
                json={"model": self.s.llm_model, "messages": messages, "temperature": 0.2,
                      "max_tokens": self.s.llm_max_tokens},
                timeout=self.s.llm_timeout_s,
            )
            r.raise_for_status()
            text = r.json()["choices"][0]["message"]["content"].strip()
            return text or None
        except Exception as exc:  # network, auth, quota, malformed payload...
            log.warning("LLM call failed (%s); using template fallback", type(exc).__name__)
            return None
