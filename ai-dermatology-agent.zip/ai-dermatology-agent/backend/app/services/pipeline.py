"""Orchestrates: validate -> vision -> risk -> RAG -> explanation."""
from __future__ import annotations

import logging
import re
import uuid

from ..config import Settings
from ..schemas import (
    AnalyzeResponse, ChatRequest, ChatResponse, Citation, ClinicalMetadata, GradCamResult, Prediction,
)
from . import risk as risk_rules
from .classes import CLASS_INFO, CLASSES
from .llm import LLMClient
from .preprocessing import load_image
from .rag import Chunk, KnowledgeBase
from .vision import VisionModel

log = logging.getLogger(__name__)

DISCLAIMER = (
    "Educational, preliminary screening support only. This is not a medical device, does not provide a "
    "diagnosis, and does not replace a dermatologist or other qualified clinician."
)
SCOPE_NOTICE = (
    "The image model can only choose among 7 lesion categories from its training data (HAM10000: melanoma, "
    "basal cell carcinoma, actinic keratosis/Bowen's, benign keratosis, dermatofibroma, melanocytic nevus, "
    "vascular lesion). It cannot recognise rashes, eczema, psoriasis, infections, acne, or hair/nail disease, "
    "and it performs best on dermoscopic images."
)
EMERGENCY_RE = re.compile(
    r"chest pain|can'?t breathe|trouble breathing|difficulty breathing|swelling of (the )?(face|lips|tongue|throat)|"
    r"blister(s|ing)? (in|on) (my )?(mouth|eyes)|severe allergic|anaphyla|suicid|self[- ]harm",
    re.I,
)
EMERGENCY_TEXT = (
    "If you have trouble breathing, swelling of the face, lips or tongue, widespread blistering, or feel "
    "very unwell, call your local emergency number or go to emergency care now."
)


def _dedupe(items: list[str], limit: int) -> list[str]:
    seen, out = set(), []
    for i in items:
        k = i.lower()
        if k not in seen:
            seen.add(k)
            out.append(i)
    return out[:limit]


def _symptom_summary(m: ClinicalMetadata) -> str:
    bits = []
    for name in ("itching", "pain", "redness"):
        if getattr(m, name) != "none":
            bits.append(f"{name}: {getattr(m, name)}")
    if m.duration_days is not None:
        bits.append(f"present for {m.duration_days} days")
    if m.lesion_changes:
        bits.append("changes noticed: " + ", ".join(m.lesion_changes))
    if m.has_fever:
        bits.append("fever")
    if m.rapidly_spreading:
        bits.append("spreading quickly")
    if m.family_history and (m.family_history.melanoma or m.family_history.skin_cancer):
        bits.append("family history of skin cancer")
    return "; ".join(bits) or "no specific symptoms reported"


class AnalysisPipeline:
    def __init__(self, settings: Settings, vision: VisionModel, kb: KnowledgeBase, llm: LLMClient):
        self.s, self.vision, self.kb, self.llm = settings, vision, kb, llm

    # ------------------------------------------------------------------ analyze
    def analyze(self, image_bytes: bytes, meta: ClinicalMetadata) -> AnalyzeResponse:
        img = load_image(image_bytes, self.s.max_upload_bytes, self.s.min_image_side)
        warnings: list[str] = []
        preds: list[Prediction] = []
        inconclusive = False
        cam = GradCamResult(available=False, note="Heatmap unavailable because no image model is active.")

        if self.vision.can_predict:
            probs = self.vision.predict(img)
            order = sorted(range(len(CLASSES)), key=lambda i: -probs[i])
            preds = [
                Prediction(label=CLASSES[i], name=CLASS_INFO[CLASSES[i]]["name"],
                           category=CLASS_INFO[CLASSES[i]]["category"], confidence=round(probs[i], 4))
                for i in order[: self.s.top_k]
            ]
            inconclusive = preds[0].confidence < self.s.low_confidence_threshold
            if self.s.enable_gradcam:
                try:
                    cam = GradCamResult(
                        available=True, image_base64=self.vision.gradcam_overlay(img, order[0]),
                        target_label=CLASSES[order[0]],
                        note="Warmer areas influenced the top prediction more. Heatmaps show model attention, "
                             "not proof of where disease is.",
                    )
                except Exception:
                    log.exception("Grad-CAM failed")
                    cam = GradCamResult(available=False, note="Heatmap generation failed.")
            if self.vision.status == "demo_untrained":
                warnings.append("DEMO MODE: random untrained weights. Ignore all predictions and heatmaps.")
            elif inconclusive:
                warnings.append(f"Low model confidence (top score {preds[0].confidence:.0%}); treat the image result as inconclusive.")
        else:
            warnings.append("Image analysis is unavailable (no trained model). Only symptom-based guidance is shown.")
        if max(img.size) < 224:
            warnings.append("The image is small; model reliability may be reduced.")

        trusted = self.vision.trusted
        risk = risk_rules.assess(meta, preds, trusted, inconclusive)
        use_top = trusted and bool(preds) and not inconclusive
        top = preds[0] if use_top else None

        # ---- structured guidance from the knowledge base (never LLM-generated)
        lesion_src = f"lesion_{top.label}" if top else None
        prec_chunks = self.kb.by_source(lesion_src, {"Precautions"}) if lesion_src else []
        prec_chunks += self.kb.by_source("general_precautions", {"Precautions"})
        care_chunks = self.kb.by_source(lesion_src, {"When to seek care"}) if lesion_src else []
        care_chunks += self.kb.by_source("general_when_to_seek_care", {"When to seek care", "Emergency warning signs"})
        precautions = _dedupe(self.kb.bullets(prec_chunks), 8)
        referral = [risk.label] + _dedupe(self.kb.bullets(care_chunks), 7)
        if risk.level in ("urgent", "emergency"):
            referral.append(EMERGENCY_TEXT)

        # ---- retrieval for grounded explanation + citations
        query = " ".join(
            [top.name] if top else []
        ) + " " + _symptom_summary(meta) + " " + " ".join(meta.previous_conditions)
        hits = self.kb.search_chunks(query, self.s.rag_top_k)
        used: list[Chunk] = [c for c, _ in hits]
        for c in prec_chunks[:1] + care_chunks[:1]:
            if c not in used:
                used.append(c)
        citations = self._citations(used)

        explanation, src = self._explain(meta, preds, top, inconclusive, risk, used)
        return AnalyzeResponse(
            request_id=uuid.uuid4().hex[:12], model=self.vision.info(), predictions=preds,
            inconclusive=inconclusive, gradcam=cam, risk=risk, explanation=explanation,
            explanation_source=src, precautions=precautions, referral_guidance=referral,
            citations=citations, warnings=warnings, scope_notice=SCOPE_NOTICE, disclaimer=DISCLAIMER,
        )

    def _citations(self, chunks: list[Chunk]) -> list[Citation]:
        seen, out = set(), []
        for c in chunks:
            key = (c.source, c.section)
            if key not in seen:
                seen.add(key)
                out.append(self.kb.cite_chunk(c))
        return out[:6]

    # -------------------------------------------------------------- explanation
    def _explain(self, meta, preds, top, inconclusive, risk, used) -> tuple[str, str]:
        context = "\n\n".join(f"[{c.title} / {c.section}] {c.text}" for c in used)[:3000]
        if self.llm.configured and self.kb.available:
            findings = [
                f"Image model status: {self.vision.status}.",
                "Top model outputs (screening signal only): "
                + (", ".join(f"{p.name} {p.confidence:.0%}" for p in preds) if preds and self.vision.trusted
                   else "none usable"),
                f"Model inconclusive: {inconclusive}.",
                f"Reported symptoms: {_symptom_summary(meta)}.",
                f"Rule-based urgency: {risk.label}. Reasons: {' '.join(risk.rationale)}",
            ]
            prompt = ("Write a 120-180 word plain-language explanation of these findings for a patient, "
                      "grounded only in the context.\n\nFINDINGS:\n" + "\n".join(findings) +
                      "\n\nCONTEXT:\n" + context)
            text = self.llm.complete(prompt)
            if text:
                return text, "llm"
        return self._template(meta, preds, top, inconclusive, risk, used), "template"

    def _template(self, meta, preds, top, inconclusive, risk, used) -> str:
        parts: list[str] = []
        status = self.vision.status
        if top:
            parts.append(
                f"The image model's highest-scoring category was {top.name} ({top.confidence:.0%}). This is a "
                "statistical pattern match against a small set of lesion types, not a diagnosis."
            )
            ov = next((c for c in used if c.source == f"lesion_{top.label}" and c.section == "Overview"), None)
            if ov:
                parts.append(ov.text.strip().split("\n")[0])
        elif status == "demo_untrained":
            parts.append("Demo mode is active: the model has random weights, so no image result is meaningful.")
        elif inconclusive:
            parts.append("The image model was not confident enough to suggest a category, so the image result is inconclusive.")
        else:
            parts.append("Image analysis was not available, so this summary relies only on what you reported.")
        parts.append(f"Reported: {_symptom_summary(meta)}.")
        parts.append(f"Suggested urgency: {risk.label}. " + " ".join(risk.rationale[:2]))
        parts.append("Only a clinician can examine and diagnose a skin problem; please use the referral guidance below.")
        return " ".join(parts)

    # --------------------------------------------------------------------- chat
    def chat(self, req: ChatRequest) -> ChatResponse:
        emergency = bool(EMERGENCY_RE.search(req.question))
        ctx_terms = " ".join(CLASS_INFO[c]["name"] for c in req.context_labels if c in CLASS_INFO)
        hits = self.kb.search_chunks(f"{req.question} {ctx_terms}", self.s.rag_top_k)
        citations = self._citations([c for c, _ in hits])
        prefix = (EMERGENCY_TEXT + "\n\n") if emergency else ""
        if self.llm.configured and hits:
            context = "\n\n".join(f"[{c.title} / {c.section}] {c.text}" for c, _ in hits)[:3000]
            hist = [{"role": t.role, "content": t.content} for t in req.history]
            prompt = (f"Context from the knowledge base:\n{context}\n\nPatient context: urgency="
                      f"{req.risk_level or 'unknown'}, model suggestions={ctx_terms or 'none'}.\n\n"
                      f"Question: {req.question}")
            text = self.llm.complete(prompt, hist)
            if text:
                return ChatResponse(answer=prefix + text, source="llm", citations=citations, disclaimer=DISCLAIMER)
        if hits:
            best, _ = hits[0]
            body = f"From the knowledge base ({best.title}, {best.section}):\n{best.text.strip()[:700]}"
        else:
            body = ("I could not find relevant information in the knowledge base for that question. "
                    "Please ask a clinician or pharmacist.")
        return ChatResponse(answer=prefix + body, source="knowledge_base", citations=citations, disclaimer=DISCLAIMER)
