"""Server-side image validation (never trust the client's checks or Content-Type)."""
from __future__ import annotations

import io

from PIL import Image, ImageOps, UnidentifiedImageError

from ..errors import InvalidImage, PayloadTooLarge, UnsupportedMediaType

ALLOWED_FORMATS = {"JPEG", "PNG", "WEBP"}
MAX_PIXELS = 50_000_000  # decompression-bomb guard


def load_image(data: bytes, max_bytes: int, min_side: int) -> Image.Image:
    if not data:
        raise InvalidImage("The uploaded file is empty.")
    if len(data) > max_bytes:
        raise PayloadTooLarge(f"Image exceeds the {max_bytes // (1024 * 1024)} MB limit.")
    try:
        probe = Image.open(io.BytesIO(data))
        fmt = probe.format
        if fmt not in ALLOWED_FORMATS:
            raise UnsupportedMediaType("Only JPEG, PNG or WebP images are accepted.")
        if probe.width * probe.height > MAX_PIXELS:
            raise InvalidImage("Image dimensions are too large.")
        probe.verify()  # integrity check; invalidates `probe`
        img = Image.open(io.BytesIO(data))
        img.load()
    except (UnidentifiedImageError, OSError, SyntaxError, ValueError) as exc:
        raise InvalidImage("The file could not be read as a valid image.") from exc
    img = ImageOps.exif_transpose(img).convert("RGB")  # also drops EXIF/GPS metadata
    if min(img.size) < min_side:
        raise InvalidImage(f"Image is too small (minimum {min_side}px on the shorter side).")
    return img
