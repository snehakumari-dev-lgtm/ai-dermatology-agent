"""Local retrieval over the curated markdown knowledge base.

Backends:
  tfidf  scikit-learn TF-IDF + cosine (default; no model download, works offline)
  faiss  sentence-transformers embeddings + FAISS inner-product index (optional extra)
If the requested backend cannot be imported we fall back to tfidf and log it.
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass
from pathlib import Path

import numpy as np

from ..schemas import Citation

log = logging.getLogger(__name__)


@dataclass(frozen=True)
class Chunk:
    source: str   # file stem, e.g. "lesion_mel"
    title: str    # H1
    section: str  # H2
    text: str


def _parse(path: Path) -> list[Chunk]:
    title, section, buf, out = path.stem, "Overview", [], []

    def flush() -> None:
        body = "\n".join(buf).strip()
        if body:
            out.append(Chunk(path.stem, title, section, body))
        buf.clear()

    for line in path.read_text(encoding="utf-8").splitlines():
        if line.startswith("# "):
            flush()
            title = line[2:].strip()
        elif line.startswith("## "):
            flush()
            section = line[3:].strip()
        else:
            buf.append(line)
    flush()
    return out


class KnowledgeBase:
    def __init__(self, directory: Path, backend: str = "tfidf", embed_model: str = "", top_k: int = 4):
        self.directory = Path(directory)
        self.requested_backend = backend
        self.backend = "none"
        self.embed_model = embed_model
        self.top_k = top_k
        self.chunks: list[Chunk] = []
        self._vec = None
        self._matrix = None
        self._index = None
        self._encoder = None

    @property
    def available(self) -> bool:
        return bool(self.chunks) and self.backend != "none"

    def load(self) -> None:
        files = sorted(self.directory.glob("*.md"))
        self.chunks = [c for f in files for c in _parse(f)]
        if not self.chunks:
            log.warning("Knowledge base is empty (%s)", self.directory)
            return
        texts = [f"{c.title}. {c.section}. {c.text}" for c in self.chunks]
        if self.requested_backend == "faiss" and self._build_faiss(texts):
            return
        self._build_tfidf(texts)

    def _build_tfidf(self, texts: list[str]) -> None:
        from sklearn.feature_extraction.text import TfidfVectorizer

        self._vec = TfidfVectorizer(stop_words="english", ngram_range=(1, 2), sublinear_tf=True)
        self._matrix = self._vec.fit_transform(texts)
        self.backend = "tfidf"
        log.info("Knowledge base ready: %d chunks (tfidf)", len(self.chunks))

    def _build_faiss(self, texts: list[str]) -> bool:
        try:
            import faiss
            from sentence_transformers import SentenceTransformer

            self._encoder = SentenceTransformer(self.embed_model)
            emb = np.asarray(self._encoder.encode(texts, normalize_embeddings=True), dtype="float32")
            self._index = faiss.IndexFlatIP(emb.shape[1])
            self._index.add(emb)
            self.backend = "faiss"
            log.info("Knowledge base ready: %d chunks (faiss)", len(self.chunks))
            return True
        except Exception as exc:
            log.warning("FAISS backend unavailable (%s); falling back to tfidf", exc)
            return False

    # ------------------------------------------------------------------ queries
    def search(self, query: str, k: int | None = None) -> list[Citation]:
        return [self._cite(self.chunks.index(c), s) for c, s in self.search_chunks(query, k)]

    def search_chunks(self, query: str, k: int | None = None) -> list[tuple[Chunk, float]]:
        if not self.available or not query.strip():
            return []
        k = k or self.top_k
        if self.backend == "faiss":
            q = np.asarray(self._encoder.encode([query], normalize_embeddings=True), dtype="float32")
            scores, idx = self._index.search(q, min(k, len(self.chunks)))
            pairs = list(zip(idx[0].tolist(), scores[0].tolist()))
        else:
            sims = (self._matrix @ self._vec.transform([query]).T).toarray().ravel()
            order = np.argsort(-sims)[:k]
            pairs = [(int(i), float(sims[i])) for i in order]
        return [(self.chunks[i], float(s)) for i, s in pairs if s > 0.02]

    def by_source(self, source: str, sections: set[str] | None = None) -> list[Chunk]:
        return [c for c in self.chunks if c.source == source and (not sections or c.section in sections)]

    @staticmethod
    def bullets(chunks: list[Chunk]) -> list[str]:
        items: list[str] = []
        for c in chunks:
            items += [m.group(1).strip() for m in re.finditer(r"^\s*[-*]\s+(.*)$", c.text, re.M)]
        return items

    def _cite(self, i: int, score: float) -> Citation:
        c = self.chunks[i]
        snippet = re.sub(r"\s+", " ", c.text).strip()
        return Citation(
            source=c.source, title=c.title, section=c.section,
            snippet=snippet[:280] + ("…" if len(snippet) > 280 else ""), score=round(float(score), 3),
        )

    def cite_chunk(self, c: Chunk) -> Citation:
        return self._cite(self.chunks.index(c), 1.0)
