"""Transparent, rule-based urgency assessment.

These are conservative developer-defined triggers, NOT a validated clinical score.
The highest triggered level wins and every trigger is reported in `rationale`.
"""
from __future__ import annotations

from ..schemas import ClinicalMetadata, Prediction, RiskAssessment
from .classes import CONCERNING

LEVELS = ["routine", "soon", "urgent", "emergency"]
LABELS = {
    "routine": "Routine: monitor, and mention it at your next check-up",
    "soon": "See a doctor or dermatologist within 1 to 2 weeks",
    "urgent": "Get prompt medical evaluation (within a few days)",
    "emergency": "Seek same-day or emergency medical care",
}
EVOLVING = {"size", "color", "shape", "border"}


def assess(
    meta: ClinicalMetadata,
    predictions: list[Prediction],
    model_trusted: bool,
    inconclusive: bool,
) -> RiskAssessment:
    level = 0
    why: list[str] = []

    def bump(to: str, reason: str) -> None:
        nonlocal level
        level = max(level, LEVELS.index(to))
        why.append(reason)

    changes = set(meta.lesion_changes)
    if meta.has_fever and meta.rapidly_spreading:
        bump("emergency", "Fever together with a rapidly spreading skin problem can signal a serious infection or reaction.")
    elif meta.rapidly_spreading:
        bump("urgent", "A rapidly spreading skin problem needs prompt assessment.")
    if {"bleeding", "ulceration"} & changes:
        bump("soon", "Bleeding or ulceration of a skin lesion should be examined.")
    if len(changes & EVOLVING) >= 2:
        bump("urgent", "Several changes (size, colour, shape or border) match the 'evolving' warning sign for skin cancer.")
    elif changes & EVOLVING:
        bump("soon", "A lesion that is changing in size, colour, shape or border should be checked.")
    if meta.family_history and meta.family_history.melanoma and changes:
        bump("soon", "Family history of melanoma plus a changing lesion raises the need for review.")
    if meta.duration_days is not None and meta.duration_days >= 42 and (
        meta.pain != "none" or meta.itching != "none" or meta.redness != "none" or changes
    ):
        bump("soon", "A symptomatic skin problem lasting 6+ weeks should be evaluated.")
    if "severe" in (meta.pain, meta.itching, meta.redness):
        bump("soon", "Severe symptoms were reported.")

    if model_trusted and predictions and not inconclusive:
        top = predictions[0]
        if top.label == "mel":
            bump("urgent", f"The image model's top suggestion is melanoma ({top.confidence:.0%}). This is a screening signal only.")
        elif top.label == "bcc":
            bump("urgent" if top.confidence >= 0.7 else "soon", f"The image model's top suggestion is basal cell carcinoma ({top.confidence:.0%}).")
        elif top.label == "akiec":
            bump("soon", f"The image model's top suggestion is a pre-cancerous type ({top.confidence:.0%}).")
    if model_trusted and predictions:
        concerning_mass = sum(p.confidence for p in predictions if p.label in CONCERNING)
        if concerning_mass >= 0.3 and level < 1:
            bump("soon", f"Combined probability of concerning classes is {concerning_mass:.0%}.")
    if model_trusted and inconclusive and level == 0:
        why.append("The image model was not confident, so its output did not raise this rating.")
    if not model_trusted:
        why.append("No validated image model contributed; this rating uses only your reported symptoms and history.")
    if level == 0:
        why.append("No warning signs were reported. A normal result here does not rule out a problem; see a clinician if you are worried.")

    key = LEVELS[level]
    return RiskAssessment(level=key, label=LABELS[key], rationale=why)  # type: ignore[arg-type]
