"""EfficientNet-B0 skin-lesion classifier wrapper with honest availability states.

Status values:
  ready          trained checkpoint loaded (still NOT clinically validated)
  demo_untrained random weights, only if ALLOW_UNTRAINED_DEMO=true (meaningless output)
  no_checkpoint  nothing loaded; the API returns no image predictions
  torch_missing  PyTorch not importable
  load_error     checkpoint present but unusable (e.g. class mismatch)
"""
from __future__ import annotations

import logging
from pathlib import Path

from PIL import Image

from ..config import Settings
from ..schemas import ModelInfo
from .classes import CLASSES

log = logging.getLogger(__name__)

try:
    import torch
    from torch import nn
    from torchvision import models, transforms

    from .gradcam import GradCAM, overlay_heatmap

    TORCH_AVAILABLE = True
except Exception:  # pragma: no cover - depends on environment
    TORCH_AVAILABLE = False

IMG_SIZE = 224
MEAN, STD = (0.485, 0.456, 0.406), (0.229, 0.224, 0.225)
MODEL_NAME = "EfficientNet-B0 (ImageNet transfer learning)"

NOTICES = {
    "ready": (
        "Trained checkpoint loaded. The model is a narrow 7-class lesion classifier for "
        "dermoscopic-style images. It is NOT clinically validated and is not a diagnosis."
    ),
    "demo_untrained": (
        "DEMO MODE: the model has RANDOM, UNTRAINED weights. Every prediction and heatmap is "
        "meaningless and shown only to demonstrate the pipeline. Never use it for any health decision."
    ),
    "no_checkpoint": (
        "No trained checkpoint found, so image analysis is disabled. Guidance below is based "
        "only on the symptoms and history you entered. See the README to train or install weights."
    ),
    "torch_missing": "PyTorch is not installed, so image analysis is disabled.",
    "load_error": "The model checkpoint could not be loaded, so image analysis is disabled.",
}


def build_model(num_classes: int = len(CLASSES)) -> "nn.Module":
    """Architecture must stay identical to ml/model.py."""
    m = models.efficientnet_b0(weights=None)
    m.classifier[1] = nn.Linear(m.classifier[1].in_features, num_classes)
    return m


class VisionModel:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.status: str = "no_checkpoint"
        self.model = None
        self.trained_on: str | None = None
        self.metrics: dict[str, float] | None = None
        self.device = settings.device
        if TORCH_AVAILABLE:
            self.transform = transforms.Compose(
                [transforms.Resize((IMG_SIZE, IMG_SIZE)), transforms.ToTensor(), transforms.Normalize(MEAN, STD)]
            )

    # ------------------------------------------------------------------ loading
    def load(self) -> None:
        if not TORCH_AVAILABLE:
            self.status = "torch_missing"
            return
        path = Path(self.settings.model_checkpoint)
        if path.is_file():
            try:
                ckpt = torch.load(path, map_location="cpu", weights_only=True)
                if list(ckpt["classes"]) != CLASSES:
                    raise ValueError(f"class mismatch: {ckpt['classes']} != {CLASSES}")
                model = build_model()
                model.load_state_dict(ckpt["state_dict"])
                self.model = model.to(self.device).eval()
                self.trained_on = ckpt.get("dataset", "unspecified dataset")
                self.metrics = {k: float(v) for k, v in ckpt.get("test_metrics", {}).items()} or None
                self.status = "ready"
                log.info("Loaded checkpoint %s", path)
            except Exception:
                log.exception("Failed to load checkpoint %s", path)
                self.status = "load_error"
        elif self.settings.allow_untrained_demo:
            self.model = build_model().to(self.device).eval()
            self.status = "demo_untrained"
            log.warning("Running in UNTRAINED DEMO mode (random weights).")
        else:
            self.status = "no_checkpoint"
            log.warning("No checkpoint at %s; image analysis disabled.", path)

    # ---------------------------------------------------------------- inference
    @property
    def can_predict(self) -> bool:
        return self.status in ("ready", "demo_untrained") and self.model is not None

    @property
    def trusted(self) -> bool:
        """Whether predictions may influence the risk assessment."""
        return self.status == "ready"

    def info(self) -> ModelInfo:
        return ModelInfo(
            status=self.status,  # type: ignore[arg-type]
            name=MODEL_NAME,
            trained_on=self.trained_on,
            classes=CLASSES,
            held_out_metrics=self.metrics,
            notice=NOTICES[self.status],
        )

    def predict(self, img: Image.Image) -> list[float]:
        assert self.can_predict
        x = self.transform(img).unsqueeze(0).to(self.device)
        with torch.no_grad():
            probs = torch.softmax(self.model(x), dim=1)[0]
        return probs.cpu().tolist()

    def gradcam_overlay(self, img: Image.Image, class_idx: int) -> str:
        assert self.can_predict
        x = self.transform(img).unsqueeze(0).to(self.device)
        cam_engine = GradCAM(self.model, self.model.features[-1])
        try:
            cam = cam_engine(x, class_idx)
        finally:
            cam_engine.close()
        return overlay_heatmap(img, cam)
