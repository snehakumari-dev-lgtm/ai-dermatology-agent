import io
import os

import pytest
from PIL import Image

os.environ["MODEL_CHECKPOINT"] = "/nonexistent/model.pt"
os.environ["LLM_API_KEY"] = ""
os.environ["ALLOW_UNTRAINED_DEMO"] = "false"


def make_image(size=(256, 256), fmt="JPEG") -> bytes:
    buf = io.BytesIO()
    Image.effect_noise(size, 40).convert("RGB").save(buf, format=fmt)
    return buf.getvalue()


@pytest.fixture
def img_bytes():
    return make_image()


def build_client(monkeypatch, demo: bool):
    from fastapi.testclient import TestClient

    from app.config import get_settings
    from app.main import create_app

    monkeypatch.setenv("ALLOW_UNTRAINED_DEMO", "true" if demo else "false")
    get_settings.cache_clear()
    return TestClient(create_app())


@pytest.fixture
def client(monkeypatch):
    with build_client(monkeypatch, demo=False) as c:
        yield c


@pytest.fixture
def demo_client(monkeypatch):
    with build_client(monkeypatch, demo=True) as c:
        yield c
