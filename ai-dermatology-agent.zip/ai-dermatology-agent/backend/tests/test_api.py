import json


def post(client, img, meta=None, name="x.jpg", ctype="image/jpeg"):
    return client.post(
        "/api/v1/analyze",
        files={"image": (name, img, ctype)},
        data={"metadata": json.dumps(meta or {})},
    )


def test_health_no_model(client):
    r = client.get("/api/v1/health").json()
    assert r["model_status"] == "no_checkpoint"
    assert r["status"] == "degraded"
    assert r["rag_available"] and r["knowledge_chunks"] > 10


def test_analyze_without_model_gives_no_predictions(client, img_bytes):
    r = post(client, img_bytes, {"itching": "mild", "duration_days": 10})
    assert r.status_code == 200
    body = r.json()
    assert body["predictions"] == []
    assert body["model"]["status"] == "no_checkpoint"
    assert body["model"]["clinically_validated"] is False
    assert body["gradcam"]["available"] is False
    assert body["precautions"] and body["referral_guidance"]
    assert "not a medical device" in body["disclaimer"].lower()
    assert body["explanation_source"] == "template"


def test_symptom_rules_escalate(client, img_bytes):
    r = post(client, img_bytes, {"lesion_changes": ["size", "color"]}).json()
    assert r["risk"]["level"] == "urgent"
    r = post(client, img_bytes, {"has_fever": True, "rapidly_spreading": True}).json()
    assert r["risk"]["level"] == "emergency"


def test_demo_mode_is_labelled_and_ignored_for_risk(demo_client, img_bytes):
    body = post(demo_client, img_bytes).json()
    assert body["model"]["status"] == "demo_untrained"
    assert "DEMO" in body["model"]["notice"]
    assert len(body["predictions"]) == 3
    assert body["gradcam"]["available"] and body["gradcam"]["image_base64"]
    assert any("DEMO" in w for w in body["warnings"])
    assert body["risk"]["level"] == "routine"  # random predictions must not drive risk


def test_rejects_non_image(client):
    r = post(client, b"not an image", name="a.jpg")
    assert r.status_code == 422 and r.json()["error"]["code"] == "invalid_image"


def test_rejects_unsupported_format(client):
    from tests.conftest import make_image

    r = post(client, make_image(fmt="GIF"), name="a.gif", ctype="image/gif")
    assert r.status_code == 415


def test_rejects_tiny_and_oversize(client):
    from tests.conftest import make_image

    assert post(client, make_image((20, 20))).status_code == 422
    assert post(client, b"0" * (9 * 1024 * 1024)).status_code == 413


def test_bad_metadata(client, img_bytes):
    r = client.post("/api/v1/analyze", files={"image": ("x.jpg", img_bytes, "image/jpeg")}, data={"metadata": "{bad"})
    assert r.status_code == 422 and r.json()["error"]["code"] == "invalid_metadata"
    assert post(client, img_bytes, {"age": 500}).status_code == 422


def test_chat_fallback_and_emergency(client):
    r = client.post("/api/v1/chat", json={"question": "What does the ABCDE rule mean for moles?"}).json()
    assert r["source"] == "knowledge_base" and r["citations"]
    r = client.post("/api/v1/chat", json={"question": "my lips are swelling and I have trouble breathing"}).json()
    assert "emergency" in r["answer"].lower()
