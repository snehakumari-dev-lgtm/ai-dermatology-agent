from app.schemas import ClinicalMetadata, Prediction
from app.services import risk
from app.services.rag import KnowledgeBase
from app.config import get_settings


def pred(label, p):
    return Prediction(label=label, name=label, category="malignant", confidence=p)


def test_trusted_melanoma_is_urgent():
    r = risk.assess(ClinicalMetadata(), [pred("mel", 0.8)], model_trusted=True, inconclusive=False)
    assert r.level == "urgent"


def test_untrusted_predictions_ignored():
    r = risk.assess(ClinicalMetadata(), [pred("mel", 0.99)], model_trusted=False, inconclusive=False)
    assert r.level == "routine"


def test_inconclusive_low_concern_is_ignored():
    r = risk.assess(ClinicalMetadata(), [pred("nv", 0.4), pred("mel", 0.1)], model_trusted=True, inconclusive=True)
    assert r.level == "routine"


def test_inconclusive_but_high_concerning_mass_still_escalates_safely():
    r = risk.assess(ClinicalMetadata(), [pred("mel", 0.4), pred("nv", 0.35)], model_trusted=True, inconclusive=True)
    assert r.level == "soon"


def test_benign_top_but_concerning_mass_is_soon():
    preds = [pred("nv", 0.6), pred("mel", 0.25), pred("bcc", 0.1)]
    assert risk.assess(ClinicalMetadata(), preds, True, False).level == "soon"


def test_rag_retrieval_finds_relevant_chunk():
    s = get_settings()
    kb = KnowledgeBase(s.knowledge_dir, "tfidf")
    kb.load()
    hits = kb.search("bleeding sore that does not heal pearly bump")
    assert hits and hits[0].source == "lesion_bcc"
    assert kb.bullets(kb.by_source("lesion_mel", {"Precautions"}))
