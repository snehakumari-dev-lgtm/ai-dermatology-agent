# Architecture, stack rationale and trade-offs

```
React+TS+Tailwind (Vite)  --multipart/JSON-->  FastAPI (/api/v1)  -->  AnalysisPipeline
  Landing > Intake > Progress > Results/Chat       health | analyze | chat      |-- preprocessing (server-side validation, EXIF stripped)
                                                                                |-- VisionModel (EfficientNet-B0) + Grad-CAM
                                                                                |-- risk rules (transparent, highest level wins)
                                                                                |-- KnowledgeBase (markdown -> chunks -> TF-IDF | FAISS)
                                                                                '-- LLMClient (OpenAI-compatible) -> template fallback
```

## Why this stack
| Choice | Why | Alternatives / trade-off |
|---|---|---|
| FastAPI + Pydantic v2 | typed contracts, auto OpenAPI, async uploads | Django is heavier; Flask lacks native validation |
| EfficientNet-B0 | strong accuracy/size ratio, trains on a free Colab T4, small checkpoint (~16 MB) | ResNet-50 is simpler for Grad-CAM but 6x larger; ViTs need more data/compute |
| Grad-CAM on `features[-1]` | no extra dependency, 7x7 map, well understood | coarse resolution; shows attention, not pathology |
| TF-IDF default, FAISS optional | works offline with no model download; ~40 chunks does not need ANN | embeddings capture synonyms better; enable with `RAG_BACKEND=faiss` |
| OpenAI-compatible LLM client | works with OpenAI, Ollama, vLLM, Together, etc. by changing a URL | no streaming yet |
| Structured guidance from the KB, LLM only for prose | precautions/referral text can never be hallucinated | less fluent than free-form generation |
| Lesion-level data split | HAM10000 has multiple images per lesion; image-level splits leak | slightly lower (honest) metrics |
| Vite + React | fast DX, static build | no SSR (not needed) |

## Honesty mechanisms (by design)
- `ModelInfo.status` is one of `ready | demo_untrained | no_checkpoint | torch_missing | load_error`. Without a checkpoint the API
  returns **no predictions**. `ALLOW_UNTRAINED_DEMO=true` loads random weights, labelled DEMO everywhere, and predictions are
  **excluded from risk scoring**.
- `clinically_validated` is a literal `False` in the schema.
- Low top-1 confidence marks the result *inconclusive*; but a combined probability >= 30% on concerning classes still raises urgency (safety-first).
- Images are processed in memory and never written to disk; free-text notes are never logged or sent to the LLM.

## Known gaps / technical debt
- No auth, rate limiting or audit log (add before any public deployment).
- No probability calibration (temperature scaling) and no out-of-distribution detector: a photo of a non-lesion can still get a confident class.
- No fairness evaluation across skin tones (use Fitzpatrick17k / DDI for that).
- Knowledge base is not clinician-reviewed.
- Frontend has no automated tests; Docker files are unexercised.

## MVP vs later
Now: train on HAM10000, evaluate honestly, demo the end-to-end flow. Later: calibration + OOD rejection, multi-condition data (ISIC 2019/2020, Fitzpatrick17k),
conversational memory, PDF report export, auth + rate limiting, clinician review of the knowledge base, MLflow experiment tracking.
