import { Activity, ScanSearch } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { analyze, getHealth } from "./api";
import ImageUpload from "./components/ImageUpload";
import Landing from "./components/Landing";
import ProgressSteps from "./components/ProgressSteps";
import ResultsDashboard from "./components/ResultsDashboard";
import StatusBanner from "./components/StatusBanner";
import SymptomForm from "./components/SymptomForm";
import { emptyMetadata } from "./types";
import type { AnalyzeResponse, ClinicalMetadata, HealthResponse } from "./types";

type View = "landing" | "intake" | "analyzing" | "results";

export default function App() {
  const [view, setView] = useState<View>("landing");
  const [file, setFile] = useState<File | null>(null);
  const [meta, setMeta] = useState<ClinicalMetadata>(emptyMetadata);
  const [agree, setAgree] = useState(false);
  const [result, setResult] = useState<AnalyzeResponse | null>(null);
  const [health, setHealth] = useState<HealthResponse | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => { getHealth().then(setHealth).catch((e: Error) => setError(e.message)); }, []);
  const previewUrl = useMemo(() => (file ? URL.createObjectURL(file) : null), [file]);
  useEffect(() => () => { if (previewUrl) URL.revokeObjectURL(previewUrl); }, [previewUrl]);

  async function submit() {
    if (!file) return;
    setError(null); setView("analyzing");
    try {
      setResult(await analyze(file, meta));
      setView("results");
    } catch (e) {
      setError(e instanceof Error ? e.message : "Analysis failed.");
      setView("intake");
    }
  }

  function reset() { setFile(null); setMeta(emptyMetadata()); setAgree(false); setResult(null); setError(null); setView("intake"); }

  return (
    <div className="min-h-screen">
      <header className="border-b border-slate-200 bg-white">
        <div className="mx-auto flex max-w-5xl items-center justify-between px-4 py-3">
          <button className="flex items-center gap-2 font-display text-lg text-brand-900" onClick={() => view !== "analyzing" && setView("landing")}>
            <Activity className="text-brand-600" size={22} /> DermAssist
          </button>
          <span className="rounded-full bg-amber-100 px-3 py-1 text-xs font-medium text-amber-900">Educational · not a diagnosis</span>
        </div>
      </header>

      <main className="mx-auto max-w-5xl px-4 py-8">
        {view !== "landing" && view !== "results" && <StatusBanner health={health} error={error} />}

        {view === "landing" && <Landing onStart={() => setView("intake")} />}

        {view === "intake" && (
          <div className="space-y-6">
            <h2 className="font-display text-3xl">New screening</h2>
            <section className="card"><h3 className="mb-3 font-semibold">1. Skin image</h3><ImageUpload file={file} onChange={setFile} /></section>
            <section className="card"><h3 className="mb-3 font-semibold">2. Symptoms and history</h3><SymptomForm value={meta} onChange={setMeta} /></section>
            <label className="flex items-start gap-2 text-sm">
              <input type="checkbox" className="mt-1 h-4 w-4 accent-brand-600" checked={agree} onChange={(e) => setAgree(e.target.checked)} />
              I understand this is an educational tool that gives no diagnosis and does not replace a doctor.
            </label>
            <button className="btn-primary" disabled={!file || !agree} onClick={submit}><ScanSearch size={18} /> Analyse</button>
          </div>
        )}

        {view === "analyzing" && <ProgressSteps />}

        {view === "results" && result && <ResultsDashboard result={result} previewUrl={previewUrl} onReset={reset} />}
      </main>
    </div>
  );
}
