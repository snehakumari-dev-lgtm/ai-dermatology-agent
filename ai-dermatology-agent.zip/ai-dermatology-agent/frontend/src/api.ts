import type { AnalyzeResponse, ChatResponse, ChatTurn, ClinicalMetadata, HealthResponse, UrgencyLevel } from "./types";

const BASE = (import.meta.env.VITE_API_BASE as string | undefined) ?? "";

export class ApiError extends Error {
  constructor(message: string, public status: number) { super(message); }
}

async function parse<T>(res: Response): Promise<T> {
  if (res.ok) return (await res.json()) as T;
  let msg = `Request failed (${res.status})`;
  try { msg = (await res.json()).error?.message ?? msg; } catch { /* non-JSON error body */ }
  throw new ApiError(msg, res.status);
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  try {
    return await parse<T>(await fetch(`${BASE}${path}`, init));
  } catch (e) {
    if (e instanceof ApiError) throw e;
    throw new ApiError("Cannot reach the analysis server. Is the backend running?", 0);
  }
}

export const getHealth = () => request<HealthResponse>("/api/v1/health");

export function analyze(image: File, metadata: ClinicalMetadata): Promise<AnalyzeResponse> {
  const form = new FormData();
  form.append("image", image);
  form.append("metadata", JSON.stringify(metadata));
  return request<AnalyzeResponse>("/api/v1/analyze", { method: "POST", body: form });
}

export function chat(question: string, history: ChatTurn[], labels: string[], risk: UrgencyLevel): Promise<ChatResponse> {
  return request<ChatResponse>("/api/v1/chat", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ question, history: history.slice(-6), context_labels: labels, risk_level: risk }),
  });
}
