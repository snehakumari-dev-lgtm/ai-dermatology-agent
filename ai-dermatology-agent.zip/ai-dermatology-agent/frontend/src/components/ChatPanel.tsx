import { Loader2, Send } from "lucide-react";
import { FormEvent, useState } from "react";
import { chat } from "../api";
import type { ChatTurn, UrgencyLevel } from "../types";

export default function ChatPanel({ labels, risk }: { labels: string[]; risk: UrgencyLevel }) {
  const [turns, setTurns] = useState<ChatTurn[]>([]);
  const [q, setQ] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  async function send(e: FormEvent) {
    e.preventDefault();
    const question = q.trim();
    if (question.length < 2 || busy) return;
    setQ(""); setErr(null); setBusy(true);
    const history = turns;
    setTurns([...history, { role: "user", content: question }]);
    try {
      const r = await chat(question, history, labels, risk);
      setTurns((t) => [...t, { role: "assistant", content: r.answer }]);
    } catch (ex) {
      setErr(ex instanceof Error ? ex.message : "Something went wrong.");
    } finally { setBusy(false); }
  }

  return (
    <section className="card">
      <h3 className="font-semibold">Ask a follow-up</h3>
      <p className="mb-3 text-xs text-slate-500">Answers come from the curated knowledge base (and an LLM if configured). Not medical advice.</p>
      <div className="mb-3 max-h-80 space-y-3 overflow-y-auto" aria-live="polite">
        {turns.map((t, i) => (
          <div key={i} className={`whitespace-pre-wrap rounded-xl px-3 py-2 text-sm ${t.role === "user" ? "ml-10 bg-brand-50" : "mr-10 bg-slate-100"}`}>{t.content}</div>
        ))}
        {busy && <Loader2 className="animate-spin text-brand-600" size={18} />}
      </div>
      {err && <p role="alert" className="mb-2 text-sm text-red-700">{err}</p>}
      <form onSubmit={send} className="flex gap-2">
        <input className="input" value={q} onChange={(e) => setQ(e.target.value)} maxLength={1000} placeholder="e.g. What does the ABCDE rule mean?" aria-label="Your question" />
        <button className="btn-primary" disabled={busy || q.trim().length < 2} aria-label="Send"><Send size={16} /></button>
      </form>
    </section>
  );
}
