import { ImagePlus, Trash2 } from "lucide-react";
import { useCallback, useEffect, useRef, useState } from "react";

export const MAX_MB = 8;
const TYPES = ["image/jpeg", "image/png", "image/webp"];

interface Props { file: File | null; onChange: (f: File | null) => void }

export default function ImageUpload({ file, onChange }: Props) {
  const [preview, setPreview] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [drag, setDrag] = useState(false);
  const input = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!file) { setPreview(null); return; }
    const url = URL.createObjectURL(file);
    setPreview(url);
    return () => URL.revokeObjectURL(url);
  }, [file]);

  const accept = useCallback((f: File | undefined) => {
    if (!f) return;
    if (!TYPES.includes(f.type)) return setError("Please choose a JPEG, PNG or WebP image.");
    if (f.size > MAX_MB * 1024 * 1024) return setError(`Image is larger than ${MAX_MB} MB.`);
    setError(null);
    onChange(f);
  }, [onChange]);

  const clear = () => { onChange(null); setError(null); if (input.current) input.current.value = ""; };

  return (
    <div>
      {preview ? (
        <div className="relative overflow-hidden rounded-2xl border border-slate-200 bg-slate-900">
          <img src={preview} alt="Selected skin area preview" className="mx-auto max-h-80 w-auto object-contain" />
          <button type="button" onClick={clear} className="absolute right-3 top-3 inline-flex items-center gap-1 rounded-lg bg-white/90 px-3 py-1.5 text-sm font-medium text-slate-800 shadow hover:bg-white">
            <Trash2 size={14} /> Remove
          </button>
          <p className="bg-slate-800 px-3 py-1.5 text-xs text-slate-300">{file?.name} · {((file?.size ?? 0) / 1024).toFixed(0)} KB · processed in memory, not stored</p>
        </div>
      ) : (
        <label
          onDragOver={(e) => { e.preventDefault(); setDrag(true); }}
          onDragLeave={() => setDrag(false)}
          onDrop={(e) => { e.preventDefault(); setDrag(false); accept(e.dataTransfer.files[0]); }}
          className={`flex cursor-pointer flex-col items-center justify-center rounded-2xl border-2 border-dashed px-6 py-14 text-center transition ${drag ? "border-brand-500 bg-brand-50" : "border-slate-300 bg-white hover:border-brand-500"}`}
        >
          <ImagePlus className="text-brand-600" size={32} />
          <span className="mt-3 font-medium">Drop a photo here or click to browse</span>
          <span className="mt-1 text-xs text-slate-500">JPEG, PNG or WebP · up to {MAX_MB} MB · well-lit, in focus, lesion centred</span>
          <input ref={input} type="file" accept={TYPES.join(",")} className="sr-only" onChange={(e) => accept(e.target.files?.[0])} />
        </label>
      )}
      {error && <p role="alert" className="mt-2 text-sm text-red-700">{error}</p>}
    </div>
  );
}
