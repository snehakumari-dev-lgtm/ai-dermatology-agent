import { ArrowRight, Brain, FileSearch, ShieldAlert, Siren, Stethoscope } from "lucide-react";

export default function Landing({ onStart }: { onStart: () => void }) {
  return (
    <div className="space-y-8">
      <section className="rounded-3xl bg-brand-900 px-6 py-12 text-white sm:px-12">
        <p className="mb-3 text-sm font-medium uppercase tracking-widest text-brand-100">Educational research prototype</p>
        <h1 className="max-w-2xl font-display text-4xl leading-tight sm:text-5xl">
          AI-driven dermatological screening and decision support
        </h1>
        <p className="mt-4 max-w-2xl text-brand-100">
          Upload a skin photo, describe your symptoms, and get an explainable, preliminary view: model suggestions with
          confidence, a Grad-CAM heatmap, an urgency category, precautions and when to see a clinician.
        </p>
        <button className="btn-primary mt-8 !bg-white !text-brand-900 hover:!bg-brand-50" onClick={onStart}>
          Start a screening <ArrowRight size={18} />
        </button>
      </section>

      <section className="rounded-2xl border-2 border-amber-300 bg-amber-50 p-5">
        <h2 className="flex items-center gap-2 font-semibold text-amber-900"><ShieldAlert size={20} /> Medical disclaimer</h2>
        <p className="mt-2 text-sm text-amber-900">
          This tool provides <strong>preliminary, educational screening support only</strong>. It is <strong>not a medical device</strong>,
          gives <strong>no diagnosis</strong>, and <strong>does not replace a dermatologist</strong> or any qualified clinician.
          The image model is a narrow classifier trained on 7 lesion types (HAM10000). It cannot detect rashes, eczema,
          psoriasis, infections, acne, or hair and nail disease, and it may be less accurate on darker skin tones and phone photos.
        </p>
      </section>

      <section className="rounded-2xl border-2 border-red-300 bg-red-50 p-5">
        <h2 className="flex items-center gap-2 font-semibold text-red-900"><Siren size={20} /> Seek emergency care immediately if you have</h2>
        <ul className="mt-2 list-disc space-y-1 pl-5 text-sm text-red-900">
          <li>Fever with a rapidly spreading, painful or blistering rash</li>
          <li>Swelling of the face, lips, tongue or throat, or trouble breathing</li>
          <li>Widespread blistering or peeling skin, or sores in the mouth or eyes</li>
          <li>Feeling very unwell, confused or faint along with a skin change</li>
        </ul>
        <p className="mt-2 text-sm font-medium text-red-900">Do not wait for this tool: call your local emergency number.</p>
      </section>

      <section className="grid gap-4 sm:grid-cols-3">
        {[
          { icon: Brain, t: "Vision model + Grad-CAM", d: "EfficientNet-B0 transfer learning with a heatmap of where the model looked." },
          { icon: FileSearch, t: "Evidence-grounded guidance", d: "Retrieval over a curated knowledge base; every explanation cites its sources." },
          { icon: Stethoscope, t: "Transparent urgency rules", d: "Symptom and history rules you can inspect, never a hidden score." },
        ].map(({ icon: Icon, t, d }) => (
          <div key={t} className="card">
            <Icon className="text-brand-600" size={22} />
            <h3 className="mt-3 font-semibold">{t}</h3>
            <p className="mt-1 text-sm text-slate-600">{d}</p>
          </div>
        ))}
      </section>
    </div>
  );
}
