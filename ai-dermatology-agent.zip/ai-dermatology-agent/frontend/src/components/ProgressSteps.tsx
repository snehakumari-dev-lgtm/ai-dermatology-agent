import { CheckCircle2, Loader2 } from "lucide-react";
import { useEffect, useState } from "react";

const STEPS = [
  "Validating and preparing the image",
  "Running the vision model",
  "Generating the Grad-CAM heatmap",
  "Applying symptom and history rules",
  "Retrieving guideline evidence",
  "Composing your explanation",
];

/** Steps advance on a timer while the single backend request is in flight (the API is not streaming),
 *  holding on the last step until the response arrives. It is an estimate of progress, not a live trace. */
export default function ProgressSteps() {
  const [active, setActive] = useState(0);
  useEffect(() => {
    const id = setInterval(() => setActive((a) => Math.min(a + 1, STEPS.length - 1)), 900);
    return () => clearInterval(id);
  }, []);
  return (
    <div className="card mx-auto max-w-md" role="status" aria-live="polite">
      <h2 className="mb-4 font-display text-xl">Analysing…</h2>
      <ol className="space-y-3">
        {STEPS.map((s, i) => (
          <li key={s} className={`flex items-center gap-3 text-sm ${i > active ? "text-slate-400" : "text-slate-800"}`}>
            {i < active ? <CheckCircle2 size={18} className="text-brand-600" /> : i === active ? <Loader2 size={18} className="animate-spin text-brand-600" /> : <span className="h-[18px] w-[18px] rounded-full border border-slate-300" />}
            {s}
          </li>
        ))}
      </ol>
    </div>
  );
}
