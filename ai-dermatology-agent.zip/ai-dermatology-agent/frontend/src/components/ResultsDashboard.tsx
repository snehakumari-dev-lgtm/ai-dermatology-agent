import { AlertOctagon, AlertTriangle, BookOpen, CheckCircle2, Eye, ListChecks, RotateCcw, Stethoscope } from "lucide-react";
import type { AnalyzeResponse, UrgencyLevel } from "../types";
import ChatPanel from "./ChatPanel";

const RISK_STYLE: Record<UrgencyLevel, { box: string; icon: typeof CheckCircle2 }> = {
  routine: { box: "border-emerald-300 bg-emerald-50 text-emerald-900", icon: CheckCircle2 },
  soon: { box: "border-amber-300 bg-amber-50 text-amber-900", icon: AlertTriangle },
  urgent: { box: "border-orange-400 bg-orange-50 text-orange-900", icon: AlertTriangle },
  emergency: { box: "border-red-500 bg-red-50 text-red-900", icon: AlertOctagon },
};
const CAT_BAR = { malignant: "bg-red-500", premalignant: "bg-amber-500", benign: "bg-brand-500" } as const;

interface Props { result: AnalyzeResponse; previewUrl: string | null; onReset: () => void }

export default function ResultsDashboard({ result: r, previewUrl, onReset }: Props) {
  const risk = RISK_STYLE[r.risk.level];
  const RiskIcon = risk.icon;
  const demo = r.model.status === "demo_untrained";

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h2 className="font-display text-3xl">Your screening summary</h2>
        <button className="btn-ghost" onClick={onReset}><RotateCcw size={16} /> New analysis</button>
      </div>

      {demo && (
        <div role="alert" className="rounded-xl border-2 border-red-500 bg-red-50 p-4 text-sm font-semibold text-red-900">{r.model.notice}</div>
      )}

      <section className={`rounded-2xl border-2 p-5 ${risk.box}`} aria-label="Urgency">
        <div className="flex items-start gap-3">
          <RiskIcon size={26} className="mt-0.5 shrink-0" />
          <div>
            <p className="text-xs font-semibold uppercase tracking-wider opacity-70">Urgency category: {r.risk.level}</p>
            <p className="text-lg font-semibold">{r.risk.label}</p>
            <ul className="mt-2 list-disc space-y-1 pl-5 text-sm">{r.risk.rationale.map((x) => <li key={x}>{x}</li>)}</ul>
          </div>
        </div>
      </section>

      {r.warnings.filter((w) => !w.startsWith("DEMO")).map((w) => (
        <div key={w} className="flex items-start gap-2 rounded-xl border border-amber-300 bg-amber-50 p-3 text-sm text-amber-900"><AlertTriangle size={16} className="mt-0.5 shrink-0" />{w}</div>
      ))}

      <div className="grid gap-5 lg:grid-cols-2">
        <section className="card">
          <h3 className="flex items-center gap-2 font-semibold"><Stethoscope size={18} className="text-brand-600" /> Image model suggestions</h3>
          {r.predictions.length === 0 ? (
            <p className="mt-3 text-sm text-slate-600">{r.model.notice}</p>
          ) : (
            <>
              <p className="mt-1 text-xs text-slate-500">
                {demo ? "Random weights: meaningless." : "Confidence is the model's own score among its 7 classes, not the probability that you have the condition."}
                {r.inconclusive && " The model was not confident: treat as inconclusive."}
              </p>
              <ul className="mt-3 space-y-3">
                {r.predictions.map((p) => (
                  <li key={p.label}>
                    <div className="flex justify-between text-sm"><span className="font-medium">{p.name}</span><span className="tabular-nums">{(p.confidence * 100).toFixed(1)}%</span></div>
                    <div className="mt-1 h-2 rounded-full bg-slate-100" role="progressbar" aria-valuenow={Math.round(p.confidence * 100)} aria-valuemin={0} aria-valuemax={100} aria-label={p.name}>
                      <div className={`h-2 rounded-full ${CAT_BAR[p.category]}`} style={{ width: `${p.confidence * 100}%` }} />
                    </div>
                    <p className="mt-0.5 text-xs capitalize text-slate-500">{p.category}</p>
                  </li>
                ))}
              </ul>
            </>
          )}
          {r.model.held_out_metrics && (
            <p className="mt-4 text-xs text-slate-500">
              Held-out metrics from training: {Object.entries(r.model.held_out_metrics).map(([k, v]) => `${k.replace(/_/g, " ")} ${(v * 100).toFixed(1)}%`).join(" · ")}. Not clinical validation.
            </p>
          )}
        </section>

        <section className="card">
          <h3 className="flex items-center gap-2 font-semibold"><Eye size={18} className="text-brand-600" /> Grad-CAM heatmap</h3>
          {r.gradcam.available && r.gradcam.image_base64 ? (
            <div className="mt-3 grid grid-cols-2 gap-2">
              {previewUrl && <figure><img src={previewUrl} alt="Original" className="aspect-square w-full rounded-lg object-cover" /><figcaption className="mt-1 text-center text-xs text-slate-500">Original</figcaption></figure>}
              <figure><img src={`data:image/png;base64,${r.gradcam.image_base64}`} alt={`Heatmap for ${r.gradcam.target_label}`} className="aspect-square w-full rounded-lg object-cover" /><figcaption className="mt-1 text-center text-xs text-slate-500">Model attention ({r.gradcam.target_label})</figcaption></figure>
            </div>
          ) : <p className="mt-3 text-sm text-slate-600">{r.gradcam.note}</p>}
          {r.gradcam.available && <p className="mt-3 text-xs text-slate-500">{r.gradcam.note}</p>}
        </section>
      </div>

      <section className="card">
        <h3 className="font-semibold">Explanation</h3>
        <p className="mt-2 text-sm leading-relaxed text-slate-700">{r.explanation}</p>
        <p className="mt-2 text-xs text-slate-400">{r.explanation_source === "llm" ? "Written by an LLM from retrieved knowledge-base text." : "Template summary (no LLM configured)."}</p>
      </section>

      <div className="grid gap-5 lg:grid-cols-2">
        <section className="card">
          <h3 className="flex items-center gap-2 font-semibold"><ListChecks size={18} className="text-brand-600" /> Precautions</h3>
          <ul className="mt-2 list-disc space-y-1.5 pl-5 text-sm text-slate-700">{r.precautions.map((p) => <li key={p}>{p}</li>)}</ul>
        </section>
        <section className="card">
          <h3 className="flex items-center gap-2 font-semibold"><Stethoscope size={18} className="text-brand-600" /> When to see a clinician</h3>
          <ul className="mt-2 list-disc space-y-1.5 pl-5 text-sm text-slate-700">{r.referral_guidance.map((p) => <li key={p}>{p}</li>)}</ul>
        </section>
      </div>

      <details className="card">
        <summary className="flex cursor-pointer items-center gap-2 font-semibold"><BookOpen size={18} className="text-brand-600" /> Evidence used ({r.citations.length})</summary>
        <ul className="mt-3 space-y-3">
          {r.citations.map((c) => (
            <li key={`${c.source}-${c.section}`} className="text-sm">
              <p className="font-medium">{c.title} <span className="font-normal text-slate-500">· {c.section}</span></p>
              <p className="text-slate-600">{c.snippet}</p>
            </li>
          ))}
        </ul>
        <p className="mt-3 text-xs text-slate-500">Knowledge-base entries are student-written educational summaries, not clinician-reviewed guidelines.</p>
      </details>

      <ChatPanel labels={r.predictions.map((p) => p.label)} risk={r.risk.level} />

      <footer className="space-y-2 rounded-xl bg-slate-100 p-4 text-xs text-slate-600">
        <p><strong>Scope:</strong> {r.scope_notice}</p>
        <p><strong>Disclaimer:</strong> {r.disclaimer}</p>
      </footer>
    </div>
  );
}
