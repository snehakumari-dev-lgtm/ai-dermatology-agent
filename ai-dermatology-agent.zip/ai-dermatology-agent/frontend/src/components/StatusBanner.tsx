import { AlertTriangle, CheckCircle2, FlaskConical } from "lucide-react";
import type { HealthResponse } from "../types";

export default function StatusBanner({ health, error }: { health: HealthResponse | null; error: string | null }) {
  if (error) {
    return (
      <div role="alert" className="mb-4 flex items-start gap-2 rounded-xl border border-red-300 bg-red-50 p-3 text-sm text-red-900">
        <AlertTriangle size={18} className="mt-0.5 shrink-0" /> {error}
      </div>
    );
  }
  if (!health) return null;
  const s = health.model_status;
  if (s === "ready") {
    return (
      <div className="mb-4 flex items-start gap-2 rounded-xl border border-emerald-200 bg-emerald-50 p-3 text-sm text-emerald-900">
        <CheckCircle2 size={18} className="mt-0.5 shrink-0" /> Trained model loaded. Still a research prototype: not clinically validated.
      </div>
    );
  }
  if (s === "demo_untrained") {
    return (
      <div role="alert" className="mb-4 flex items-start gap-2 rounded-xl border-2 border-red-400 bg-red-50 p-3 text-sm font-medium text-red-900">
        <FlaskConical size={18} className="mt-0.5 shrink-0" /> {health.notice}
      </div>
    );
  }
  return (
    <div role="status" className="mb-4 flex items-start gap-2 rounded-xl border border-amber-300 bg-amber-50 p-3 text-sm text-amber-900">
      <AlertTriangle size={18} className="mt-0.5 shrink-0" /> {health.notice}
    </div>
  );
}
