import type { ClinicalMetadata, LesionChange, Severity } from "../types";

interface Props { value: ClinicalMetadata; onChange: (v: ClinicalMetadata) => void }

const SEVERITIES: Severity[] = ["none", "mild", "moderate", "severe"];
const CHANGES: { id: LesionChange; label: string }[] = [
  { id: "size", label: "Growing / size change" }, { id: "color", label: "Colour change" },
  { id: "shape", label: "Shape change" }, { id: "border", label: "Border became irregular" },
  { id: "bleeding", label: "Bleeding" }, { id: "ulceration", label: "Open sore / ulcer" },
  { id: "crusting", label: "Crusting" }, { id: "itching_new", label: "New itching in the lesion" },
];

function Segmented({ label, value, onChange }: { label: string; value: Severity; onChange: (s: Severity) => void }) {
  return (
    <fieldset>
      <legend className="label">{label}</legend>
      <div className="inline-flex overflow-hidden rounded-lg border border-slate-300">
        {SEVERITIES.map((s) => (
          <button key={s} type="button" aria-pressed={value === s} onClick={() => onChange(s)}
            className={`px-3 py-1.5 text-sm capitalize transition ${value === s ? "bg-brand-600 text-white" : "bg-white text-slate-700 hover:bg-slate-100"}`}>
            {s}
          </button>
        ))}
      </div>
    </fieldset>
  );
}

export default function SymptomForm({ value: v, onChange }: Props) {
  const set = <K extends keyof ClinicalMetadata>(k: K, val: ClinicalMetadata[K]) => onChange({ ...v, [k]: val });
  const fam = v.family_history ?? { skin_cancer: false, melanoma: false, relatives: [] };
  const toggleChange = (id: LesionChange) =>
    set("lesion_changes", v.lesion_changes.includes(id) ? v.lesion_changes.filter((c) => c !== id) : [...v.lesion_changes, id]);

  return (
    <div className="space-y-5">
      <div className="grid gap-4 sm:grid-cols-3">
        <div>
          <label className="label" htmlFor="age">Age (optional)</label>
          <input id="age" type="number" min={0} max={120} className="input" value={v.age ?? ""}
            onChange={(e) => set("age", e.target.value === "" ? null : Math.min(120, Math.max(0, Number(e.target.value))))} />
        </div>
        <div>
          <label className="label" htmlFor="sex">Sex</label>
          <select id="sex" className="input" value={v.sex} onChange={(e) => set("sex", e.target.value as ClinicalMetadata["sex"])}>
            <option value="unspecified">Prefer not to say</option><option value="female">Female</option>
            <option value="male">Male</option><option value="other">Other</option>
          </select>
        </div>
        <div>
          <label className="label" htmlFor="site">Body site</label>
          <input id="site" maxLength={60} placeholder="e.g. left forearm" className="input" value={v.body_site ?? ""}
            onChange={(e) => set("body_site", e.target.value || null)} />
        </div>
      </div>

      <div className="flex flex-wrap gap-x-8 gap-y-4">
        <Segmented label="Itching" value={v.itching} onChange={(s) => set("itching", s)} />
        <Segmented label="Pain / tenderness" value={v.pain} onChange={(s) => set("pain", s)} />
        <Segmented label="Redness" value={v.redness} onChange={(s) => set("redness", s)} />
      </div>

      <div className="max-w-xs">
        <label className="label" htmlFor="dur">How long has it been there? (days)</label>
        <input id="dur" type="number" min={0} max={36500} className="input" value={v.duration_days ?? ""}
          onChange={(e) => set("duration_days", e.target.value === "" ? null : Math.max(0, Number(e.target.value)))} />
      </div>

      <fieldset>
        <legend className="label">Has the lesion changed recently?</legend>
        <div className="grid gap-2 sm:grid-cols-2">
          {CHANGES.map((c) => (
            <label key={c.id} className="flex items-center gap-2 text-sm">
              <input type="checkbox" className="h-4 w-4 accent-brand-600" checked={v.lesion_changes.includes(c.id)} onChange={() => toggleChange(c.id)} /> {c.label}
            </label>
          ))}
        </div>
      </fieldset>

      <div className="flex flex-wrap gap-6 text-sm">
        <label className="flex items-center gap-2"><input type="checkbox" className="h-4 w-4 accent-brand-600" checked={v.has_fever} onChange={(e) => set("has_fever", e.target.checked)} /> I have a fever</label>
        <label className="flex items-center gap-2"><input type="checkbox" className="h-4 w-4 accent-brand-600" checked={v.rapidly_spreading} onChange={(e) => set("rapidly_spreading", e.target.checked)} /> It is spreading quickly</label>
      </div>

      <div>
        <label className="label" htmlFor="prev">Previous skin conditions (comma-separated)</label>
        <input id="prev" className="input" placeholder="e.g. eczema, previous skin cancer, many moles"
          defaultValue={v.previous_conditions.join(", ")}
          onChange={(e) => set("previous_conditions", e.target.value.split(",").map((s) => s.trim()).filter(Boolean).slice(0, 10))} />
      </div>

      <fieldset className="rounded-xl bg-slate-50 p-4">
        <legend className="label !mb-0 px-1">Family history (optional)</legend>
        <div className="mt-2 flex flex-wrap gap-6 text-sm">
          <label className="flex items-center gap-2"><input type="checkbox" className="h-4 w-4 accent-brand-600" checked={fam.skin_cancer} onChange={(e) => set("family_history", { ...fam, skin_cancer: e.target.checked })} /> Skin cancer in a relative</label>
          <label className="flex items-center gap-2"><input type="checkbox" className="h-4 w-4 accent-brand-600" checked={fam.melanoma} onChange={(e) => set("family_history", { ...fam, melanoma: e.target.checked })} /> Melanoma in a relative</label>
        </div>
        <p className="mt-2 text-xs text-slate-500">Family history raises awareness only; it cannot establish a diagnosis.</p>
      </fieldset>

      <div>
        <label className="label" htmlFor="notes">Anything else? (optional, max 500 characters)</label>
        <textarea id="notes" rows={2} maxLength={500} className="input" value={v.notes ?? ""} onChange={(e) => set("notes", e.target.value || null)} />
      </div>
    </div>
  );
}
