// Mirrors backend/app/schemas.py
export type Severity = "none" | "mild" | "moderate" | "severe";
export type LesionChange = "size" | "color" | "shape" | "border" | "bleeding" | "ulceration" | "crusting" | "itching_new";
export type UrgencyLevel = "routine" | "soon" | "urgent" | "emergency";

export interface FamilyHistory {
  skin_cancer: boolean;
  melanoma: boolean;
  other_conditions?: string | null;
  relatives: string[];
}

export interface ClinicalMetadata {
  age?: number | null;
  sex: "female" | "male" | "other" | "unspecified";
  body_site?: string | null;
  itching: Severity;
  pain: Severity;
  redness: Severity;
  duration_days?: number | null;
  lesion_changes: LesionChange[];
  has_fever: boolean;
  rapidly_spreading: boolean;
  previous_conditions: string[];
  family_history?: FamilyHistory | null;
  notes?: string | null;
}

export interface Prediction { label: string; name: string; category: "malignant" | "premalignant" | "benign"; confidence: number }
export interface ModelInfo {
  status: "ready" | "demo_untrained" | "no_checkpoint" | "torch_missing" | "load_error";
  name: string; trained_on?: string | null; classes: string[];
  held_out_metrics?: Record<string, number> | null; clinically_validated: false; notice: string;
}
export interface GradCamResult { available: boolean; image_base64?: string | null; target_label?: string | null; note: string }
export interface Citation { source: string; title: string; section: string; snippet: string; score: number }
export interface RiskAssessment { level: UrgencyLevel; label: string; rationale: string[] }

export interface AnalyzeResponse {
  request_id: string; model: ModelInfo; predictions: Prediction[]; inconclusive: boolean;
  gradcam: GradCamResult; risk: RiskAssessment; explanation: string; explanation_source: "llm" | "template";
  precautions: string[]; referral_guidance: string[]; citations: Citation[]; warnings: string[];
  scope_notice: string; disclaimer: string;
}

export interface ChatTurn { role: "user" | "assistant"; content: string }
export interface ChatResponse { answer: string; source: "llm" | "knowledge_base"; citations: Citation[]; disclaimer: string }
export interface HealthResponse {
  status: "ok" | "degraded"; version: string; model_name: string; model_status: string;
  rag_available: boolean; rag_backend: string; knowledge_chunks: number; llm_configured: boolean; notice: string;
}

export const emptyMetadata = (): ClinicalMetadata => ({
  sex: "unspecified", itching: "none", pain: "none", redness: "none",
  lesion_changes: [], has_fever: false, rapidly_spreading: false, previous_conditions: [],
});
