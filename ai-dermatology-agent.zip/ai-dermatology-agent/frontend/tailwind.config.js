/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      fontFamily: { sans: ["Inter", "system-ui", "sans-serif"], display: ["Fraunces", "Georgia", "serif"] },
      colors: { brand: { 50: "#effaf8", 100: "#d3f3ee", 500: "#14a393", 600: "#0f8579", 700: "#0d6b62", 900: "#0a3f3b" } },
    },
  },
  plugins: [],
};
