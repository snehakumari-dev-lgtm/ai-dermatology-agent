"""HAM10000 class vocabulary. Order MUST match backend/app/services/classes.py."""
CLASSES = ["akiec", "bcc", "bkl", "df", "mel", "nv", "vasc"]
CLASS_TO_IDX = {c: i for i, c in enumerate(CLASSES)}
MALIGNANT = {"mel", "bcc", "akiec"}
FULL_NAMES = {
    "akiec": "Actinic keratosis / Bowen's disease", "bcc": "Basal cell carcinoma",
    "bkl": "Benign keratosis-like lesion", "df": "Dermatofibroma", "mel": "Melanoma",
    "nv": "Melanocytic nevus", "vasc": "Vascular lesion",
}
IMG_SIZE = 224
MEAN, STD = (0.485, 0.456, 0.406), (0.229, 0.224, 0.225)
