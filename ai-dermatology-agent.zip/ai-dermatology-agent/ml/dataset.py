from __future__ import annotations

import json
from pathlib import Path

import pandas as pd
import torch
from PIL import Image
from torch.utils.data import DataLoader, Dataset
from torchvision import transforms

from classes import CLASS_TO_IDX, IMG_SIZE, MEAN, STD


def train_tfms() -> transforms.Compose:
    return transforms.Compose([
        transforms.Resize((IMG_SIZE, IMG_SIZE)),
        transforms.RandomHorizontalFlip(), transforms.RandomVerticalFlip(),
        transforms.RandomRotation(25),
        transforms.ColorJitter(0.2, 0.2, 0.2, 0.02),
        transforms.ToTensor(), transforms.Normalize(MEAN, STD),
    ])


def eval_tfms() -> transforms.Compose:  # identical to backend preprocessing
    return transforms.Compose([transforms.Resize((IMG_SIZE, IMG_SIZE)), transforms.ToTensor(), transforms.Normalize(MEAN, STD)])


class SkinLesionDataset(Dataset):
    def __init__(self, manifest: pd.DataFrame, root: Path, transform):
        self.df = manifest.reset_index(drop=True)
        self.root, self.transform = Path(root), transform

    def __len__(self) -> int:
        return len(self.df)

    def __getitem__(self, i: int):
        row = self.df.iloc[i]
        img = Image.open(self.root / row["path"]).convert("RGB")
        return self.transform(img), CLASS_TO_IDX[row["dx"]]


def load_manifest(manifest_path: Path, root: Path | None = None) -> tuple[pd.DataFrame, Path]:
    df = pd.read_csv(manifest_path)
    if root is None:
        root = Path(json.loads((Path(manifest_path).parent / "manifest_meta.json").read_text())["image_root"])
    return df, Path(root)


def make_loader(df: pd.DataFrame, root: Path, train: bool, batch_size: int, num_workers: int) -> DataLoader:
    ds = SkinLesionDataset(df, root, train_tfms() if train else eval_tfms())
    return DataLoader(ds, batch_size=batch_size, shuffle=train, num_workers=num_workers,
                      pin_memory=torch.cuda.is_available(), drop_last=train and len(ds) > batch_size)
