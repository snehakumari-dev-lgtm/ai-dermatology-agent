"""Held-out TEST evaluation: classification report, per-class sensitivity/specificity, confusion matrix.

  python evaluate.py --checkpoint ../backend/models/skin_lesion_effnet_b0.pt --manifest data/processed/manifest.csv
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
from sklearn.metrics import classification_report, confusion_matrix

from classes import CLASSES
from dataset import load_manifest, make_loader
from model import build_model
from utils import compute_metrics, predict_loader


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--checkpoint", type=Path, default=Path("../backend/models/skin_lesion_effnet_b0.pt"))
    ap.add_argument("--manifest", type=Path, default=Path("data/processed/manifest.csv"))
    ap.add_argument("--root", type=Path, default=None)
    ap.add_argument("--split", default="test", choices=["val", "test"])
    ap.add_argument("--out-dir", type=Path, default=Path("reports"))
    ap.add_argument("--batch-size", type=int, default=64)
    a = ap.parse_args()

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    ckpt = torch.load(a.checkpoint, map_location="cpu", weights_only=True)
    assert list(ckpt["classes"]) == CLASSES, "class order mismatch"
    model = build_model(pretrained=False)
    model.load_state_dict(ckpt["state_dict"]); model.to(device)

    df, root = load_manifest(a.manifest, a.root)
    loader = make_loader(df[df.split == a.split], root, False, a.batch_size, 2)
    probs, labels = predict_loader(model, loader, device)
    metrics = compute_metrics(probs, labels)
    pred = probs.argmax(1)
    cm = confusion_matrix(labels, pred, labels=range(len(CLASSES)))

    per_class = {}
    for i, c in enumerate(CLASSES):
        tp = cm[i, i]; fn = cm[i].sum() - tp; fp = cm[:, i].sum() - tp; tn = cm.sum() - tp - fn - fp
        per_class[c] = {"sensitivity": float(tp / max(1, tp + fn)), "specificity": float(tn / max(1, tn + fp)), "support": int(cm[i].sum())}

    a.out_dir.mkdir(parents=True, exist_ok=True)
    report = classification_report(labels, pred, labels=range(len(CLASSES)), target_names=CLASSES, zero_division=0)
    (a.out_dir / f"{a.split}_report.txt").write_text(report)
    (a.out_dir / f"{a.split}_metrics.json").write_text(json.dumps({"overall": metrics, "per_class": per_class}, indent=2))

    fig, ax = plt.subplots(figsize=(6.5, 5.5))
    norm = cm / np.maximum(cm.sum(1, keepdims=True), 1)
    ax.imshow(norm, cmap="Blues", vmin=0, vmax=1)
    ax.set_xticks(range(len(CLASSES)), CLASSES, rotation=45); ax.set_yticks(range(len(CLASSES)), CLASSES)
    for i in range(len(CLASSES)):
        for j in range(len(CLASSES)):
            ax.text(j, i, cm[i, j], ha="center", va="center", color="white" if norm[i, j] > 0.5 else "black", fontsize=8)
    ax.set_xlabel("Predicted"); ax.set_ylabel("True"); ax.set_title(f"Confusion matrix ({a.split})")
    fig.tight_layout(); fig.savefig(a.out_dir / f"{a.split}_confusion_matrix.png", dpi=150)

    print(report); print(json.dumps(metrics, indent=2))
    print(f"Reports written to {a.out_dir}/. Class imbalance means accuracy alone is misleading; "
          "look at macro-F1, melanoma recall and per-class sensitivity.")


if __name__ == "__main__":
    main()
