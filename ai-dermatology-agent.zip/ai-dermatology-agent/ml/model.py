"""EfficientNet-B0 transfer-learning model. Architecture must stay identical to backend/app/services/vision.py."""
from __future__ import annotations

import logging

import torch
from torch import nn
from torchvision import models

from classes import CLASSES

log = logging.getLogger(__name__)


def build_model(num_classes: int = len(CLASSES), pretrained: bool = True) -> nn.Module:
    weights = models.EfficientNet_B0_Weights.IMAGENET1K_V1 if pretrained else None
    try:
        m = models.efficientnet_b0(weights=weights)
    except Exception as exc:  # offline / blocked download
        log.warning("Could not load pretrained weights (%s). Using random init.", exc)
        m = models.efficientnet_b0(weights=None)
    m.classifier = nn.Sequential(nn.Dropout(0.3, inplace=True), nn.Linear(m.classifier[1].in_features, num_classes))
    return m


def set_backbone_trainable(model: nn.Module, trainable: bool) -> None:
    for p in model.features.parameters():
        p.requires_grad = trainable
