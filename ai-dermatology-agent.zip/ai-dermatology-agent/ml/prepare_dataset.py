"""Inspect HAM10000, clean it, and create a LESION-LEVEL stratified train/val/test split.

HAM10000 has several images per lesion (lesion_id). Splitting by image leaks near-duplicates between
train and test and inflates accuracy, so we split by lesion_id.

Usage:
  python prepare_dataset.py --raw-dir data/raw/HAM10000 --out-dir data/processed
  python prepare_dataset.py --download --raw-dir data/raw/HAM10000     # needs ~/.kaggle/kaggle.json

Expected raw layout (any sub-folder structure works; images are found recursively):
  HAM10000_metadata.csv          columns: lesion_id, image_id, dx, dx_type, age, sex, localization
  HAM10000_images_part_1/*.jpg
  HAM10000_images_part_2/*.jpg
Sources: https://dataverse.harvard.edu/dataset.xhtml?persistentId=doi:10.7910/DVN/DBW86T
         https://www.kaggle.com/datasets/kmader/skin-cancer-mnist-ham10000   https://www.isic-archive.com
Respect each dataset's license/terms of use.
"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path

import pandas as pd
from sklearn.model_selection import StratifiedGroupKFold

from classes import CLASSES


def download(raw_dir: Path) -> None:
    raw_dir.mkdir(parents=True, exist_ok=True)
    cmd = ["kaggle", "datasets", "download", "-d", "kmader/skin-cancer-mnist-ham10000", "-p", str(raw_dir), "--unzip"]
    print("Running:", " ".join(cmd))
    try:
        subprocess.run(cmd, check=True)
    except (FileNotFoundError, subprocess.CalledProcessError) as exc:
        sys.exit(f"Kaggle download failed ({exc}). Install the kaggle CLI + API token, or download manually (see docstring).")


def split(df: pd.DataFrame, seed: int) -> pd.DataFrame:
    y, g = df["dx"], df["lesion_id"]
    outer = StratifiedGroupKFold(n_splits=10, shuffle=True, random_state=seed)  # ~10% test
    rest_idx, test_idx = next(outer.split(df, y, g))
    rest = df.iloc[rest_idx]
    inner = StratifiedGroupKFold(n_splits=9, shuffle=True, random_state=seed)   # ~10% of total as val
    tr_i, va_i = next(inner.split(rest, rest["dx"], rest["lesion_id"]))
    df = df.copy()
    df["split"] = "train"
    df.loc[rest.index[va_i], "split"] = "val"
    df.iloc[test_idx, df.columns.get_loc("split")] = "test"
    return df


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--raw-dir", type=Path, required=True)
    ap.add_argument("--out-dir", type=Path, default=Path("data/processed"))
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--download", action="store_true", help="download HAM10000 via the Kaggle CLI first")
    a = ap.parse_args()

    if a.download:
        download(a.raw_dir)
    metas = list(a.raw_dir.rglob("HAM10000_metadata*.csv")) or list(a.raw_dir.rglob("*metadata*.csv"))
    if not metas:
        sys.exit(f"No HAM10000 metadata CSV found under {a.raw_dir}. See the docstring for the expected layout.")
    meta = pd.read_csv(metas[0])
    need = {"lesion_id", "image_id", "dx"}
    if not need <= set(meta.columns):
        sys.exit(f"Metadata must contain {need}; found {list(meta.columns)}")
    print(f"Metadata: {metas[0]}  ({len(meta)} rows)")

    images = {p.stem: p for ext in ("*.jpg", "*.jpeg", "*.png") for p in a.raw_dir.rglob(ext)}
    n0 = len(meta)
    meta = meta.drop_duplicates("image_id")
    meta = meta[meta["dx"].isin(CLASSES)]
    meta["path"] = meta["image_id"].map(lambda i: str(images[i].relative_to(a.raw_dir)) if i in images else None)
    missing = int(meta["path"].isna().sum())
    meta = meta.dropna(subset=["path"]).reset_index(drop=True)
    print(f"Cleaning: {n0} -> {len(meta)} rows ({missing} without an image file, others duplicate/unknown label)")
    if meta.empty:
        sys.exit("No usable rows after cleaning; check --raw-dir.")

    meta = split(meta, a.seed)
    leak = (set(meta[meta.split == "train"].lesion_id) & set(meta[meta.split == "test"].lesion_id)) | \
           (set(meta[meta.split == "train"].lesion_id) & set(meta[meta.split == "val"].lesion_id))
    assert not leak, "lesion leakage between splits!"

    a.out_dir.mkdir(parents=True, exist_ok=True)
    keep = [c for c in ["image_id", "lesion_id", "dx", "path", "split", "age", "sex", "localization"] if c in meta.columns]
    meta[keep].to_csv(a.out_dir / "manifest.csv", index=False)
    (a.out_dir / "manifest_meta.json").write_text(json.dumps({"image_root": str(a.raw_dir.resolve()), "classes": CLASSES}, indent=2))

    dist = pd.crosstab(meta["dx"], meta["split"]).reindex(CLASSES).fillna(0).astype(int)
    dist["total"] = dist.sum(axis=1)
    dist["pct"] = (dist["total"] / dist["total"].sum() * 100).round(1)
    (a.out_dir / "class_distribution.json").write_text(dist.to_json(indent=2))
    print("\nClass distribution (images):\n", dist.to_string())
    print(f"\nWrote {a.out_dir/'manifest.csv'}. Note the heavy imbalance (nv ~67%); train.py uses class-weighted loss.")


if __name__ == "__main__":
    main()
