"""Fine-tune EfficientNet-B0 on the manifest produced by prepare_dataset.py.

  python train.py --manifest data/processed/manifest.csv --epochs 25
Phase 1 trains only the new head (--freeze-epochs); phase 2 fine-tunes the whole network at a lower LR.
The checkpoint with the best VALIDATION macro-F1 is saved; TEST metrics are computed once, at the end.
"""
from __future__ import annotations

import argparse
import json
import random
import time
from pathlib import Path

import numpy as np
import torch
from torch import nn
from tqdm import tqdm

from classes import CLASSES
from dataset import load_manifest, make_loader
from model import build_model, set_backbone_trainable
from utils import compute_metrics, predict_loader


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--manifest", type=Path, default=Path("data/processed/manifest.csv"))
    ap.add_argument("--root", type=Path, default=None, help="image root (default: from manifest_meta.json)")
    ap.add_argument("--out", type=Path, default=Path("../backend/models/skin_lesion_effnet_b0.pt"))
    ap.add_argument("--epochs", type=int, default=25)
    ap.add_argument("--freeze-epochs", type=int, default=3)
    ap.add_argument("--batch-size", type=int, default=32)
    ap.add_argument("--lr", type=float, default=3e-4)
    ap.add_argument("--weight-decay", type=float, default=1e-4)
    ap.add_argument("--patience", type=int, default=6)
    ap.add_argument("--num-workers", type=int, default=2)
    ap.add_argument("--no-pretrained", action="store_true", help="random init (smoke tests only)")
    ap.add_argument("--max-samples", type=int, default=0, help="debug: cap samples per split")
    ap.add_argument("--seed", type=int, default=42)
    a = ap.parse_args()

    random.seed(a.seed); np.random.seed(a.seed); torch.manual_seed(a.seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "mps" if torch.backends.mps.is_available() else "cpu")
    print("Device:", device)

    df, root = load_manifest(a.manifest, a.root)
    parts = {s: df[df.split == s] for s in ("train", "val", "test")}
    if a.max_samples:
        parts = {s: d.sample(min(len(d), a.max_samples), random_state=a.seed) for s, d in parts.items()}
    loaders = {s: make_loader(d, root, s == "train", a.batch_size, a.num_workers) for s, d in parts.items()}
    print({s: len(d) for s, d in parts.items()})

    counts = parts["train"]["dx"].value_counts().reindex(CLASSES).fillna(0).values.astype(float)
    weights = torch.tensor((counts.sum() / np.maximum(counts, 1)) ** 0.5, dtype=torch.float32)
    weights = (weights / weights.mean()).to(device)  # inverse-sqrt-frequency weighting
    criterion = nn.CrossEntropyLoss(weight=weights, label_smoothing=0.05)

    model = build_model(pretrained=not a.no_pretrained).to(device)
    scaler = torch.amp.GradScaler(enabled=device.type == "cuda")
    best_f1, best_state, bad, history = -1.0, None, 0, []

    def make_opt(lr):
        return torch.optim.AdamW([p for p in model.parameters() if p.requires_grad], lr=lr, weight_decay=a.weight_decay)

    for epoch in range(a.epochs):
        if epoch == 0:
            set_backbone_trainable(model, False); opt = make_opt(a.lr)
        if epoch == a.freeze_epochs:
            set_backbone_trainable(model, True); opt = make_opt(a.lr / 10)
            sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=max(1, a.epochs - epoch))
        model.train(); t0, run = time.time(), 0.0
        for x, y in tqdm(loaders["train"], desc=f"epoch {epoch+1}/{a.epochs}", leave=False):
            x, y = x.to(device), y.to(device)
            opt.zero_grad(set_to_none=True)
            with torch.autocast(device_type=device.type, enabled=device.type == "cuda"):
                loss = criterion(model(x), y)
            scaler.scale(loss).backward(); scaler.step(opt); scaler.update()
            run += loss.item() * len(x)
        if epoch >= a.freeze_epochs:
            sched.step()
        vp, vl = predict_loader(model, loaders["val"], device)
        vm = compute_metrics(vp, vl)
        history.append({"epoch": epoch + 1, "train_loss": run / max(1, len(parts["train"])), **{f"val_{k}": v for k, v in vm.items()}})
        print(f"epoch {epoch+1}: loss={history[-1]['train_loss']:.4f} val_macro_f1={vm['macro_f1']:.4f} "
              f"val_bal_acc={vm['balanced_accuracy']:.4f} ({time.time()-t0:.0f}s)")
        if vm["macro_f1"] > best_f1:
            best_f1, bad = vm["macro_f1"], 0
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
        else:
            bad += 1
            if epoch >= a.freeze_epochs and bad >= a.patience:
                print("Early stopping."); break

    model.load_state_dict(best_state)
    tp, tl = predict_loader(model, loaders["test"], device)
    test_metrics = compute_metrics(tp, tl)
    print("TEST metrics (held-out, lesion-level split):", json.dumps(test_metrics, indent=2))

    a.out.parent.mkdir(parents=True, exist_ok=True)
    torch.save({
        "state_dict": best_state, "classes": CLASSES, "arch": "efficientnet_b0", "img_size": 224,
        "dataset": "HAM10000 (7 classes, lesion-level split)" + (" [SMOKE TEST - random init]" if a.no_pretrained else ""),
        "test_metrics": test_metrics, "best_val_macro_f1": best_f1,
    }, a.out)
    a.out.with_suffix(".history.json").write_text(json.dumps(history, indent=2))
    print(f"Saved {a.out}. Run evaluate.py for the full report. This model is NOT clinically validated.")


if __name__ == "__main__":
    main()
