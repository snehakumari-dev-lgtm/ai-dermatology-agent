from __future__ import annotations

import numpy as np
import torch
from sklearn.metrics import balanced_accuracy_score, f1_score, roc_auc_score

from classes import CLASSES, CLASS_TO_IDX


@torch.no_grad()
def predict_loader(model, loader, device) -> tuple[np.ndarray, np.ndarray]:
    model.eval()
    probs, labels = [], []
    for x, y in loader:
        probs.append(torch.softmax(model(x.to(device)), dim=1).cpu().numpy())
        labels.append(y.numpy())
    return np.concatenate(probs), np.concatenate(labels)


def compute_metrics(probs: np.ndarray, labels: np.ndarray) -> dict[str, float]:
    pred = probs.argmax(1)
    m = {
        "accuracy": float((pred == labels).mean()),
        "balanced_accuracy": float(balanced_accuracy_score(labels, pred)),
        "macro_f1": float(f1_score(labels, pred, average="macro", labels=range(len(CLASSES)), zero_division=0)),
    }
    present = set(labels.tolist())
    if len(present) == len(CLASSES):  # AUROC is undefined when a class is absent from the split
        try:
            m["macro_auroc"] = float(roc_auc_score(labels, probs, multi_class="ovr", labels=list(range(len(CLASSES)))))
        except ValueError:
            pass
    mel = CLASS_TO_IDX["mel"]
    if (labels == mel).any():
        m["melanoma_recall"] = float((pred[labels == mel] == mel).mean())
    return m
