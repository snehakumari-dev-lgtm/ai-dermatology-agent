#!/usr/bin/env python3
"""Bundle the project into ai-dermatology-agent.zip (excludes caches, node_modules, secrets, datasets, weights).

  python scripts/make_zip.py [output_dir]
"""
from __future__ import annotations

import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SKIP_DIRS = {"node_modules", "dist", "__pycache__", ".pytest_cache", ".venv", ".git", "data", "reports"}
SKIP_SUFFIX = {".pyc", ".pt", ".pth", ".ckpt"}
SKIP_NAMES = {".env", "ai-dermatology-agent.zip"}


def included(p: Path) -> bool:
    rel = p.relative_to(ROOT)
    if rel.parts[0] == "ml" and "data" in rel.parts[1:2]:
        return False
    return not (set(rel.parts[:-1]) & SKIP_DIRS or p.suffix in SKIP_SUFFIX or p.name in SKIP_NAMES)


def main() -> None:
    out_dir = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT.parent
    out = out_dir / "ai-dermatology-agent.zip"
    files = sorted(p for p in ROOT.rglob("*") if p.is_file() and included(p))
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for p in files:
            z.write(p, Path("ai-dermatology-agent") / p.relative_to(ROOT))
    print(f"Wrote {out} ({len(files)} files, {out.stat().st_size/1024:.0f} KB)")


if __name__ == "__main__":
    main()
